int main() 
{
	const CURRENT_YEAR = 2020;
    char ch1 = ' ', ch2 = ' ', ch3 = ' ';
    int year = 0, number=0, age=0;

    printf("Enter the first letter:   ");
    ch1 = getchar();
    getchar();

    printf("Enter the second letter:   ");
    ch2 = getchar();
    getchar();

    printf("Enter the third letter:   ");
    ch3 = getchar();
    getchar();

    printf("\nHey %c%c%c, what year were you born? ",ch1,ch2,ch3);
    scanf("%d", &year);

    printf("\nPlease choose any number you would like from 1-100? ");
    scanf("%d", &number);

    age = CURRENT_YEAR - year;

    printf("\nYou are %d years old\n%d %% %d = %d", age, age, number, age % number);
  
    return 0;
}