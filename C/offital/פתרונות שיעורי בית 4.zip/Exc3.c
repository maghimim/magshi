#include <stdlib.h>
#include <stdio.h>

#define PI 3.14

int main(void)
{
	float radius = 0.0, volume = 0.0;
	printf("Please insert the ball radius: ");
	scanf("%f", &radius);
	// We can check the radius with this calculator: https://www.calculatorsoup.com/calculators/geometry-solids/sphere.php
	volume = (4 * PI * radius * radius * radius) / 3;
	printf("The radius is: %f.\nThe volume is: %f", radius, volume);
	return 0;
} 
