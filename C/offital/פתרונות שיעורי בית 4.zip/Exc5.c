#include <stdlib.h>
#include <stdio.h>

int main() 
{
    char ch1 = ' ', ch2 = ' ', ch3 = ' ';
    
    printf("Enter the first letter:   ");
    ch1 = getchar();
    getchar();

    printf("Enter the second letter:   ");
    ch2 = getchar();
    getchar();

    printf("Enter the third letter:   ");
    ch3 = getchar();
    getchar();

    printf("\The name is %c%c%c\n");
  
  return 0;
}