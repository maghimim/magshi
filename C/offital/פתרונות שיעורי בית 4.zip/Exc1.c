#include <stdlib.h>
#include <stdio.h>

/**
The main function of the program.
*/
int main(void)
{
	// Parameters declaration and initialization:
	char a = 'H';								
	char b = 0;
	char c = 0;
	
	printf("Please enter a letter:\n");
	// Get value from the user. When using getchar an assignment is needed.
	b = getchar();
	// no need to save the return value: clean the buffer
	getchar(); 
	
	printf("Please enter a letter:\n");
	scanf("%c", &c);	// Pay attention to the '&'
	
	printf("The value of the first variable is: %c, and the value + 1 is: %c\n", a, a + 1);
	printf("The value of the first variable is: %d\n", a);
	printf("The ASCII sum of all the variables is: %d\n", a + b + c);
	printf("The ASCII sum of the first and third variables is: %d\n", a + c);
	printf("The character represented by the sum above is: %c\n", a + c);

	return 0;
} 
