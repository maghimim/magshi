/*********************************
* Class: MAGSHIMIM C1			 *
* Week 4           				 *
* Pyramid of starts				 *
**********************************/

#include <stdlib.h>
#include <stdio.h>

/**
The program prints a pyramid of starts to the CMD.

Input:
	None
Output:
	The program returns 0 upon successful completion of its running (windows convention)
*/
int main(void)
{
	// Variable declaration
	const unsigned int MIN_NUM = 5;		// Lower limit for the input
	const unsigned int MAX_NUM = 20;		// Upper limit for the input
	unsigned int num =0;					// Size of the pyramid, determined by the user
	unsigned int isValid=0;				// Flag, indicating if the input is valid
	unsigned int row=0;					// Outer loop counter
	unsigned int col=0;					// Inner loop counter

	// get input until it is valid
	do
	{
		printf("Enter number: ");
		scanf("%d", &num);

		isValid = (num >= MIN_NUM) && (num <= MAX_NUM);

		if (!isValid)
		{
			printf("Invalid input! 5~20 only\n");
		}
	}
	while (!isValid);

	// Print the pyramid. We need two loops, one for the rows and one for the columns.
	for (row = 1; row <= num; row++)
	{
		// Since we draw a triangle the upper limit is when 'col' equals 'row'.
		for (col = 1; col <= row; col++)
		{
			printf("*");
		}
		// Print a ENTER only at the end of the line.
		printf("\n");
	}

	return 0;
}