/*********************************
* Class: MAGSHIMIM C2			 *
* Week 2           				 *
* HW solution 			 	 	 *
**********************************/

#include <stdio.h>

void swap(float* x, float* y);

int main(void)
{
	float a = 0, b = 0;
	printf("Enter two numbers: ");
	scanf("%f %f", &a, &b);
	swap(&a, &b);
	printf("Swapped: %.2f %.2f", a, b);
	getchar();
	return 0;
}

/*
Function makes a swap between the values of two numbers. 
input: the numbers to swap
output: none
*/
void swap(float* x, float* y) 
{ 
	float temp = *x; 
	*x = *y; 
	*y = temp; 
}
