/*********************************
* Class: MAGSHIMIM C2			 *
* Week 2           				 *
* HW solution   			 	 *
**********************************/
#include <stdio.h>
#include <time.h>

#define RANGE 10

void mystery(int*, int*);

/*The pointers x, y points to the place wheres the values of a and b located (respectevly).
when we use the sign '*' as an operator, we get the value itself and we able to modify it as we like.*/
int main(void)
{
	int a = 0, b = 0;
	srand(time(NULL)); // seed for rand
	a = (rand() % RANGE) + 1;
	b = (rand() % RANGE) + 1;

	mystery(&a, &b);
	printf("a: %d b: %d \n", a, b);
	getchar();
	return 0;
}

/*
Function sets input number values to sum- if x's value is smaller than y's value, and the difference otherwise.
input: two pointers of int
output: none
*/
void mystery(int* x, int* y)
{
	if (*x < *y)
	{
		*x = *x + *y;
	}
	else {
		*y = *x - *y;
	}
}
