/*********************************
* Class: MAGSHIMIM C2			 *
* Week 2           				 *
* HW solution 				 	 *
**********************************/
#include <stdio.h>
#define ARR_LEN 10

void initWithIndex(int* p);

int main(void)
{
	int nums[ARR_LEN] = {0};
	int i = 0;
	initWithIndex(nums);
	for( i = 0; i < ARR_LEN; i++ )
	{
		printf("%d ", *(nums + i));
	}
	printf("\n");
	getchar();
	return 0;
}

/*
Function will enter values into an array. 
input: the array
output: none
*/
void initWithIndex(int* p)
{
	int i = 0;
	int num = 0;
	
	// Option 1
	for( i =  0 ; i < ARR_LEN ; i++ )
	{
		printf("Enter value for index %d: ", i);
		scanf("%d", &num);
		getchar();
		*(p + i) = num;
		// another option:
		// scanf("%d", p + i);
	}
	
	// Option 2
	for( i =  0 ; i < ARR_LEN ; i++, p++)
	{
		/* 
		printf("Please enter value for index %d: ", i);
		scanf("%d", p);
		*/
	}
}
