/*********************************
* Class: MAGSHIMIM C2			 *
* Week 5           				 *
* HW solution  			 	 *
**********************************/

#include <stdio.h>
#include <stdlib.h>

#define ADD_COMMAND "ADD"
#define SUB_COMMAND "SUB"

#define ADD_OP 1
#define SUB_OP -1
#define INVALID_OP 0
#define FIRST_NUMBER_INDEX 2
#define MIN_ARGS 4 // name + op + 2 numbers

int getOp(char * op);
void printUsage(void);

int main(int argc, char** argv)
{
	int result = 0;
	int curr = 0;
	int currIndex = 0;
	int op = 0;
	int temp = 0;
	int temp1 = 0;
	
	if(argc < MIN_ARGS)
	{
		printf("ERROR! INVALID NUMBER OF ARGUMENTS!\n");
		printUsage();
	}
	else
	{
		op = getOp(argv[1]);
		if (op)
		{
			currIndex = FIRST_NUMBER_INDEX;
			result = atoi(argv[currIndex]);
			currIndex++;
			while (currIndex < argc)
			{
				temp = atoi(argv[currIndex]);
				temp1 = (temp * op);
				result += temp1;
				currIndex++;
			}
			printf("Result: %d", result);
		}
	}
	getchar();
	return 0;
}

/*
Function gets the correct operation
input: the operation
output: the operation's code
*/
int getOp(char * op)
{
	int result = INVALID_OP;
	
	if(!strcmp(op, ADD_COMMAND))
	{
		result = ADD_OP;
	}
	else if(!strcmp(op, SUB_COMMAND))
	{
		result = SUB_OP;
	}
	else
	{
		printf("ERROR! INVALID COMMAND!\n");
		printUsage();
	}
	
	return result;
}

/*
Function prints the valid arguments number and order.
input: none
output: none
*/
void printUsage(void)
{
	printf("How to use the program: <ADD / SUB> <number> ... <number>");
}