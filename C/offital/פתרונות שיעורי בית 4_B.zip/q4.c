/*********************************
* Class: MAGSHIMIM C2			 *
* Week 4           				 *
* HW solution  			 	 	 *
**********************************/

#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

#define MIN_GRADE 0
#define MAX_GRADE 100

#define AVERAGE_OP 1
#define CHANGE_GRADE_OP 2
#define CHANGE_LEN_OP 3
#define PRINT_OP 4
#define EXIT_OP 5

void getAllGrades(int* gradesArr, int numOfGrades);
int getGrade(void);
int showMenu(void);
float getAverage(int* gradesArr, int numOfGrades);
void changeGrade(int* gradesArr, int numOfGrades);
void changeArrayLen(int** gradesArr, int* numOfGrades);
void printGrades(int* gradesArr, int numOfGrades);

int main(void)
{
	int numOfGrades = 0;
	int* grades = NULL;
	int op = 0;
	printf("Enter number of grades: ");
	scanf("%d", &numOfGrades);
	getchar(); //buffer cleaning
	grades = (int*)malloc(sizeof(int) * numOfGrades);
	
	getAllGrades(grades, numOfGrades);
	op = showMenu();
	
	while(op != EXIT_OP)
	{
		switch(op)
		{
			case(AVERAGE_OP):
				printf("The grades average is: %.2f\n", getAverage(grades, numOfGrades));
				break;
			case(CHANGE_GRADE_OP):
				changeGrade(grades, numOfGrades);
				break;
			case(CHANGE_LEN_OP):
				// sending addresses because we want to change them!
				changeArrayLen(&grades, &numOfGrades);
				break;
			case(PRINT_OP):
				printGrades(grades, numOfGrades);
				break;
			default:
				break;
		}
		op = showMenu();
	}			
	free(grades);
	getchar();
	return 0;
}

/*
Function fills array with grades
input: array and its length
output: none
*/
void getAllGrades(int* gradesArr, int numOfGrades)
{
	int i = 0;
	for(i = 0; i < numOfGrades; i++)
	{
		printf("Enter grade %d: ", i+1);
		gradesArr[i] = getGrade();
	}
}

/*
Function reads a valid grade from user
input: none
output: a valid grade
*/
int getGrade(void)
{
	int grade = 0;
	scanf("%d", &grade);
	getchar();
	while(!(grade >= MIN_GRADE && grade <= MAX_GRADE))
	{
		printf("Invalid grade. 0-100 only. Try again: ");
		scanf("%d", &grade);
		getchar();
	}
	return grade;	
}

/*
Function shows menu and gets user's choice
input: none
output: user's choice
*/
int showMenu(void)
{
	int op = 0;
	printf("%d - Calculate average\n", AVERAGE_OP);
	printf("%d - Change a grade\n", CHANGE_GRADE_OP);
	printf("%d - Change number of grades\n", CHANGE_LEN_OP);
	printf("%d - Print grades\n", PRINT_OP);
	printf("%d - Exit\n", EXIT_OP);
	printf("Choose option: ");
	scanf("%d", &op); 
	getchar();
	while(!(op >= AVERAGE_OP && op <= EXIT_OP))
	{
		printf("Invalid choice. Try again: ");
		scanf("%d", &op);
		getchar();
	}
	return op;
}

/*
Function calculates average of numbers
input: array and its length
output: average of numbers 
*/
float getAverage(int* gradesArr, int numOfGrades)
{
	float sum = 0.0;
	int i = 0;
	for(i = 0; i < numOfGrades; i++)
	{
		sum += (float)gradesArr[i];
	}
	return (sum / numOfGrades);

}

/*
Function lets user change a grade
input: array of grades, and its length
output: none
*/
void changeGrade(int* gradesArr, int numOfGrades)
{
	int toChange = 0;
	
	printf("Which grade would you like to change? 1-%d: ", numOfGrades);
	scanf("%d", &toChange);
	getchar();
	while(!(toChange >= 1 && toChange <= numOfGrades))
	{
		printf("Invalid choice. Try again: ");
		scanf("%d", &toChange);
		getchar();
	}
	printf("Enter new grade: ");
	gradesArr[toChange-1] = getGrade();
}

/*
Function changes length of array
input: array of grades, and its length
output: none
*/
void changeArrayLen(int** gradesArr, int* numOfGrades)
{
	int newLen = 0;
	printf("Enter new number of grades: ");
	scanf("%d", &newLen);
	*gradesArr = (int*)realloc(*gradesArr, sizeof(int) * newLen);
	
	// In case we need to fill new grades
	while(*numOfGrades < newLen)
	{
		printf("Enter grade %d: ", (*numOfGrades)+1);
		(*gradesArr)[*numOfGrades] = getGrade();
		(*numOfGrades)++;
	}
	*numOfGrades = newLen;
}

/*
Function prints all grades
input: array and its length
output: none
*/
void printGrades(int* gradesArr, int numOfGrades)
{
	int i = 0;
	for(i = 0; i < numOfGrades; i++)
	{
		printf("%d ", gradesArr[i]);
	}
	printf("\n");
}