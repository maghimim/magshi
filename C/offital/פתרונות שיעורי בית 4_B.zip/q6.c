﻿/*********************************
* Class: MAGSHIMIM C2			 *
* Week:                			 *
* Name:                          *
* Credits:                       *
**********************************/


#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/*
when we use "malloc" to allocate memory, in addition to the bytes we asked for, 
"malloc" allocates another memory, that saves the amount of bytes that were allocated.
According to this memory, "free" knows how much memory it should release.
*/
int main(void)
{
	float* mem = (float*)malloc(sizeof(float) * 100);
	free(mem);

	getchar();
	return 0;
}