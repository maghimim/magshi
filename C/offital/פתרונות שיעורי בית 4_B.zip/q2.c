/*********************************
* Class: MAGSHIMIM C2			 *
* Week 4        				 *
* HW solution   			 	 *
**********************************/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

int* createArr(int sizeOfArr);
void sortAndPrint(int *arr, int sizeOfArr);
void swap(int *first, int *second);

int main(void)
{
	int sizeOfArr = 0;
	int* arr = 0;

	printf("Enter length of array: ");
	scanf("%d", &sizeOfArr); 
	getchar();
	arr = createArr(sizeOfArr);
	sortAndPrint(arr, sizeOfArr);
	free(arr);

	getchar();
	return 0;
}

/*
Function will read length of array and create array, and read values into it, then sending it onwards
input: none
output: pointer to the array
*/
int* createArr(int sizeOfArr)
{
	int i = 0;
	int* arr = (int*)malloc(sizeof(int) * sizeOfArr);
	
	if (!arr)
	{
		printf("Error allocating memory");
	}
	printf("Enter %d numbers:\n", sizeOfArr);
	for(i = 0; i < sizeOfArr; i++)
	{
		scanf("%d", arr + i);
		getchar();
	}
	return arr;
}

/*
Function will sort and print an array
input: array and its size
output: none
*/
void sortAndPrint(int *arr, int len)
{
	int i = 0, j = 0;
	//bubble sort
	for(i = 0; i < len - 1; i++)
	{
		for(j = 0; j < len - i - 1; j++)
		{
			if (*(arr + j) > *(arr + j+1))
			{
				swap(arr + j, arr + j+1);
			}
		}
	}
	//print array
	printf("Sorted:\n");
	for(i = 0; i < len ; i++)
	{
		printf("%d\n", *(arr+i) );
	}
}

/*
Function swaps two numbers
input: the two numbers
output: none
*/
void swap(int* first, int* second)
{
	int temp = *first;
	*first = *second;
	*second = temp;
}
