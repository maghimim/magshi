/*********************************
* Class: MAGSHIMIM C1			 *
* Week 2           				 *
* Class solution 6  			 *
**********************************/

#include <stdlib.h>
#include <stdio.h>

/**
The program multiplies a number by 2 using two different methods.

Input:
	None
Output:
	The program returns 0 upon successful completion of its running
*/
int main(void)
{
	// variable definition
	float num = 34.39;

	// output 
	num = num * 2;
	printf("num = %.2f\n", num); // Use .2 to print only two digits after the point
	
	num *= 2;
	printf("num = %.2f\n", num);

	system("PAUSE");
	return (0);
} 