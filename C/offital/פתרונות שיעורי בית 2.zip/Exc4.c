/*********************************
* Class: MAGSHIMIM C1			 *
* Week 2           				 *
* Class solution 8  			 *
* Variable initialization		 *
**********************************/

#include <stdlib.h>
#include <stdio.h>

/**
What does the program print?

Input:
	None
Output:
	The program returns 0 upon successful completion of its running
*/
int main(void)
{
	int a;
	printf("%d\n", a); // answer: 'a' was never initialized so we print garbage from the memory
	return (0);
}
