/*********************************
* Class: MAGSHIMIM C1			 *
* Week 2           				 *
* HW solution 9  			 	 *
* Simple printf					 *
**********************************/

#include <stdlib.h>
#include <stdio.h>

/**
The program prints sentences to the screen.

Input:
	None
Output:
	The program returns 0 upon successful completion of its running
*/
int main(void)
{
	// first option
	printf("This is not my first message\n");
	printf("I already printed Hello World\n");
	printf("Now everything is clear\n");
	printf("YUPY!!\n");


	// second option
	printf("This is not my first message\nI already printed Hello World\nNow everything is clear\nYUPY!!\n");

	return 0;
} 