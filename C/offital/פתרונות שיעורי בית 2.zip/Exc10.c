/*********************************
* Class: MAGSHIMIM C1			 *
* Week 2           				 *
* HW solution - cousins' age	 *
* Tricky switch					 *
**********************************/


#include <stdlib.h>
#include <stdio.h>

/**
The program sums the age of cousins vs. grandparents

Input:
	None
Output:
	The program returns 0 upon successful completion of its running
*/
int main(void)
{
	int ageDaniel = 32;
	int ageSagi = 13;
	int ageAriel = 15;
	int ageElla = 20;
	int ageTom = 23;
	int ageShaked = 7;
	
	int ageSaba = 87;
	int ageSafta = 84;
	
	int sumCousins = ageDaniel + ageSagi + ageAriel + ageElla + ageTom + ageShaked;
	int sumGramps = ageSaba + ageSafta;
	
	printf("Age of cousins is %d, %d, %d, %d, %d, %d\n", ageDaniel , ageSagi , ageAriel , ageElla , ageTom , ageShaked); 
	printf("Age of Saba is %d and Safta %d\n", ageSaba, ageSafta);
	printf("Sum of cousins' age is %d and of grandparents age is %d\n", sumCousins, sumGramps);
	printf("Which is greater???\n");
	

	return 0;
} 