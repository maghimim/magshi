/*********************************
* Class: MAGSHIMIM C1			 *
* Week 4           				 *			 
**********************************/

#include <stdio.h>
#include <stdlib.h>


int main(void)
{
	// Variable declaration
	char c = 0;

	// Get a character for the user, can use also "scanf" 
	printf("Please enter a character: ");
	c = getchar();

	// Check character value.
	// Always use {}, even for one line of code.
	// Pay attention to indentation.
	if (c == 'y')
	{
		printf("YES\n");
	}
	else if (c == 'n')
	{
		printf("NO\n");
	}
	else
	{
		printf("FUZZY\n");
	}

	return 0;
}