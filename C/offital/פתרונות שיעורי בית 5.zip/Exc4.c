/*********************************
* Class: MAGSHIMIM C1			 *
* Week 4           				 *
* Question 6		  			 *
* Absolute value of a number	 *
**********************************/

#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	// Get a number from the user
	int num = 0;
	printf("Please enter a number: ");
	scanf("%d", &num);

	// In case the number is negative we should multiply it by (-1)
	if (num < 0)
	{
		num *= -1;
	}
	
	printf("The absolute value of this number is: %d\n", num);

	return 0;
}