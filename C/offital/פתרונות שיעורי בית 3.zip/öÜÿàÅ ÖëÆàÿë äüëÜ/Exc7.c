#include <stdlib.h>
#include <stdio.h>

int main(void)
{
	int day = 14;
	int month = 9;
	int year = 2005;

	char dayTensDigit = '1';
	char dayUnitsDigit = '4';
	char monthUnitsDigit = '9';
	char yearThousandsDigit = '2';
	char yearHundradsDigit = '0';
	char yearTensDigit = '0';
	char yearUnitsDigit = '5';
	
	printf("My birthday is: %d/%d/%d\n", day, month, year);
	printf("My birthday is: %c%c/%c/%c%c%c%c\n", dayTensDigit, dayUnitsDigit, monthUnitsDigit, yearThousandsDigit, yearHundradsDigit, yearTensDigit, yearUnitsDigit);
	return 0;
} 