#include <stdlib.h>
#include <stdio.h>

# define MONTHS_IN_YEAR 12

int main(void)
{
	const int WORK_DAYS = 20; // In France: 24
	const float WORK_HOURS = 8.5;
	const float HOURLY_SALARY = 32.3; // In France: 8.0807243 
	
	printf("The yearly salary in total is: %.2f", WORK_DAYS * WORK_HOURS * HOURLY_SALARY * MONTHS_IN_YEAR);
	
	return 0;
} 