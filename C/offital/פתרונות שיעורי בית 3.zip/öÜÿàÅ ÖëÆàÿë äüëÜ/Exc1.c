#include <stdlib.h>
#include <stdio.h>

int main(void)
{
	// variables definition
	int numA = 5;
	float numB = 1.1;
	
	// output. we print the product using %f because it is not necessarily a whole number.
	printf("numA = %d, numB = %f, numA * numB = %f\n", numA, numB, numA * numB);

	return 0;
} 