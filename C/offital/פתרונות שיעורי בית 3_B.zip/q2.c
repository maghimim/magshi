/*********************************
* Class: MAGSHIMIM C2			 *
* Week 3           				 *
* HW solution   			 	 *
**********************************/

#include <stdio.h>
void printAfterX(int* arr, int n, int* x);

int main(void)
{
	int arr[] = {4, 8, 6, 2, 1, 3, 5, 7, 8, 9, 5};
	int offset = 0;
	printf("Please enter an offset to search in the array's address domain: ");
	scanf("%d", &offset);
	getchar();
	printAfterX(arr, 11, arr + offset);
	getchar();
	return 0;
}

/*
The function checks if an element (cell in memory) is contained
in an array or not. If it does, it prints all the value proceeding it.
Otherwise, it informs the user about it.

Input:
	arr - array of integers
	n - array length
	x - address of an element in memory
*/
void printAfterX(int* arr, int n, int* x)
{
	if ((x >= arr) && (x < arr + n))		// x is an element in the array
	{
		x++;								// Increment by one cell
		for (; x < arr + n ; x++ )			// Print all the rest of the cells
		{
			printf("%d ", *x);
		}
	}
	else
	{
		printf("Not in the array.\n");
	}
}

