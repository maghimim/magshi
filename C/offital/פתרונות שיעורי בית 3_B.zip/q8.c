/*********************************
* Class: MAGSHIMIM C2			 *
* Week 3           				 *
* HW solution   			 	 *
**********************************/

#include <stdio.h>
void printAfterX(int* arr, int n, int* x);

int main(void)
{
	int one = 1;
	int two = 2;
	int three = 3;
	int arr[] = {4, 5, 6};
	printf("%p %p %p %p %p %p", &one, &two, &three, arr, arr+1, arr+2);
	getchar();
	return 0;
}

/* 
Your addresses will probably be different, but the order - the same!

ADDRESS |0028FEF8|0028FEFC|0028FF00|0028FF04|0028FF08|0028FF0C|
 
CONTENT |   4    |   5    |   6    |   3    |   2    |   1    |
*/