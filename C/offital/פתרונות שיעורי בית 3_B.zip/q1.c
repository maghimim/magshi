/*********************************
* Class: MAGSHIMIM C2			 *
* Week 3           				 *
* HW solution   			 	 *
**********************************/

#include <stdio.h>
#define ARR_LEN 10

void arrayInput(int * arr, int n);
void arrayReverseOutput(int * arr, int n);

int main(void)
{
	int arr[ARR_LEN] = { 0 };
	arrayInput(arr, ARR_LEN);
	arrayReverseOutput(arr, ARR_LEN);
    getchar();
	return 0;
}

/**
The function initializes an array with integer values given by the user.

Input:
	arr - array of integers, all current contents are deleted
	n - array length
*/
void arrayInput(int * arr, int n)
{
	int i = 0;
	printf("Enter %d numbers: ", n);
	for (i = 0 ; i < n; i++)
	{
		scanf("%d", arr+i);
		getchar();
	}
}

/**
The function prints to the command line the contents of an array.

Input:
	arr - array of integers, filled with values.
	n - array length
*/
void arrayReverseOutput(int * arr, int n)
{
	int i = 0;
	printf("The numbers in reverse order: ");
	for (i = n-1 ; i >= 0; i--)
	{
		printf("%d ", *(arr+i));
	}
}
