/*********************************
* Class: MAGSHIMIM C1			 *
* Week 6           				 *
* Homework solution 			 *
* Perfect number				 *
**********************************/

#include <stdlib.h>
#include <stdio.h>

#define FALSE 0
#define TRUE !FALSE

/**
The program gets a number from the user and check if it is a perfect number.
A perfect number is a positive integer number which is equal to the sum of its dividers (without itself).

Input:
	None
Output:
	The program returns 0 upon successful completion of its running (windows convention)
*/
int main(void)
{
	// Variable declaration
	unsigned int num = 0;		// The number to be checked
	unsigned int sum = 0;	// Will contain the sum of the dividers
	unsigned int divider = 1;	// Loop variable
	unsigned int isPerfect = FALSE;

	// Get user input, assume it is valid
	printf("Enter number: ");
	scanf("%d", &num);

	for(divider = 1; divider <= num-1; divider++)
	{
		// if current divider divides the input number, add it to the sum
		if(num % divider == 0)
		{
			sum += divider;
		}
	}
	
	// The number is perfect if it equals the sum of its dividers
	isPerfect = (num == sum);
	
	// Print output
	if(isPerfect)
	{
		printf("Yes! The number is perfect\n");
	}
	else
	{
		printf("No! The number is not perfect\n");
	}
		
	return 0;
}
