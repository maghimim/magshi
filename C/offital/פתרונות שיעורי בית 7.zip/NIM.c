/*********************************
* Class: MAGSHIMIM C1			 *
* Week 6 - Algorithms			 *
* NIM 				  			 *
*********************************/

#include <stdio.h>

#define FIRST_PLAYER 0
#define NUM_PLAYERS 2

#define NUM_STONES 10
#define MAX_REMOVE 3

int main(void)
{
	int player = FIRST_PLAYER;
	int stones = NUM_STONES;
	int remove = 0;
	printf("Beginning NIM with %d stones.\nYou can remove up to %d stones at a a time.\n\n", NUM_STONES, MAX_REMOVE);
	
	while(stones > 0)
	{
		printf("Player %d it is your turn.\n", player+1);
		do
		{
			printf("There are %d stones in the pile\n", stones);
			printf("You may remove 1-%d stones.\nHow many stones to remove?\n", MAX_REMOVE);
			scanf("%d", &remove);
		}
		while(!(remove > 0 && remove <= MAX_REMOVE) || remove > stones);
		stones = stones - remove;
		if(stones == 0)
		{
			printf("Player %d wins!\n", player+1);
		}
		player = (player + 1) % NUM_PLAYERS; // moving to next player (0 - first player, 1 - second player
	}
	
	return 0;
}