/*********************************
* Class: MAGSHIMIM C1			 *
* Week 6           				 *
* Bonus Solution				 *
**********************************/

#include <stdlib.h>
#include <stdio.h>

/**
The program Prints the smallest common denominator of two given numbers.
The smallest common denominator is the smallest positive integer
that is a multiple of the denominators given as input.
Input:
	None
Output:
	The program returns 0 upon successful completion of its running (windows convention)
*/
int main(void)
{
	int num1 = 0, num2 = 0;

	printf("Write the first number\n");
	scanf("%d",&num1);
	printf("Write the second number\n");
	scanf("%d",&num2);

	int result  = 1; 			// the result to be returned
	int div = 2; 		// the divider

	while ( num1 > 1 || num2 > 1)
	{
		if (num1 % div == 0)	
		{
			result *= div;		
			num1 /= div;		
			if (num2 % div == 0)
			{
				num2 /= div;
			}
		}
		else if (num2 % div == 0)
		{
			result *= div;
			num2 /= div;
		}
		else
		{
			div++;
		}
	}

	printf("The result is %d\n", result);

	return 0;
}