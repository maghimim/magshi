/*********************************
* Class: MAGSHIMIM C1			 *
* Week 6           				 *
* HW 1 Solution		 			 *
* Sum of digits					 *
*********************************/

#include <stdio.h>

#define MAX_DIGIT 9
#define TEN 10 // decimal base

#define FALSE 0
#define TRUE !FALSE

int main(void)
{
	int num = 0, copy = 0, sum = 0;
	int curr = 1; // the current digit in the number we are checking
	int found = FALSE;
	int check = 1; // loop variable to check current digit in the number
	printf("Please enter a number\n");
	scanf("%d", &num);

	for (check = 1; check <= MAX_DIGIT; check++)
	{
		copy = num; // check the next digit on the original number
		curr = num; // initialize curr
		while (copy != 0 && !found)
		{
			curr = copy % TEN; // get last digit of the number
			copy = copy / TEN; // cut number by 1

			if (curr == check) // checking for the digit we are on now
			{
				sum += check;
				found = TRUE;
			}
		}
		found = FALSE; // ready for the next digit
	}

	printf("Sum of different digits is %d\n", sum);

	return 0;
}