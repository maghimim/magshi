/*********************************
* Class: MAGSHIMIM C1			 *
* Week 10           				 *
* Class solution 2  			 *
**********************************/

#include <stdio.h>
#include <stdlib.h>

#define ARRAY_SIZE 5

void fillArray(int arr[]);
void printArrayReverse(int arr[]);

int main(void)
{	
	int arrNums[ARRAY_SIZE] = {0};
	fillArray(arrNums);
	printArrayReverse(arrNums);

	return 0;
}

/*
Fill an array with user inputs. Array's contents are erased!

Input: arr - Array to be filled
Output: None
*/
void fillArray(int arr[])
{
	int i = 0;
	printf("Enter %d numbers to array: ", ARRAY_SIZE);
	for (i = 0; i < ARRAY_SIZE; ++i)
	{		
		scanf("%d", &arr[i]);
	}
}

/*
Print array contents in reverse order.

Input: arr - Array to be filled
Output: None
*/
void printArrayReverse(int arr[])
{
	int i = 0;
	printf("Array reversed: ");
	for (i = ARRAY_SIZE - 1; i >= 0; i--)
	{
		printf("%d ", arr[i]);
	}
}
