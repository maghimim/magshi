/*********************************
* Class: MAGSHIMIM C1			 *
* Week 10           			 *	
**********************************/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define ARR_SIZE 10000
#define NUM_OF_FACES 6

int main(void)
{	
	int arrCube[ARR_SIZE];
	int i = 0;
	int j = 0;
	int sum = 0;
	int counters[NUM_OF_FACES] = {0};
	
	srand(time(NULL));	
	
	for(i = 0; i < ARR_SIZE; i++)
	{
		arrCube[i] = (rand() % NUM_OF_FACES) + 1;
	}

	// Solution
	printf("Section (a) solution:\n");
	for(i = 1; i < NUM_OF_FACES + 1; i++)
	{
		sum = 0;
		for(j = 0; j < ARR_SIZE; j++)
		{
			if(arrCube[j] == i)
			{
				sum++;
			}
		}
		printf("We got %d, %d times.\n",i ,sum);
	}
	
	// Bonus
	printf("\nBonus solution:\n");
	
	//init the counter array with 0's
	for(i = 0; i < NUM_OF_FACES; i++)
	{
		counters[i] = 0;
	}
	
	for(i = 0; i < ARR_SIZE; i++)
	{
		counters[arrCube[i] - 1]++;
	}
	
	for(i = 0; i < NUM_OF_FACES; i++)
	{
		printf("We got %d, %d times.\n",i + 1 ,counters[i]);
	}

	return 0;
}
