/*********************************
* Class: MAGSHIMIM C1			 *
* Week 7           				 *
* HW Solution					 *
**********************************/

#include <stdio.h>
#include <stdlib.h>

void printNum(int num);

int main(void)
{
	int num = 6;
	printNum(num); // no need for "int" here
	return 0;
}

/*
Function will print a number.

input: The number

output: None
*/
void printNum(int num)
{
	printf("Num is %d", num);
}



