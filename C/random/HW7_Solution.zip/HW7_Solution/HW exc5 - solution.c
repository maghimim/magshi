/*********************************
* Class: MAGSHIMIM C1			 *
* Week 7           				 *
* Homework solution   			 *
**********************************/

#include <stdlib.h>
#include <stdio.h>

// in the declaration we don't have to write the variable names!
void geometricSeries(int,int,int); 

/**
The main function of the program. 
*/
int main(void)
{
	int firstElement = 0;
    int ratio = 0; 
    int num = 0 ;
	printf("Enter first element of the series: ");
	scanf("%d",&firstElement);
	printf("Enter the series ratio: ");
	scanf("%d",&ratio);
	printf("Enter number of elements to display: ");
	scanf("%d",&num);

	geometricSeries(firstElement, ratio, num);

	return 0;
}


/**
The function prints the first elements of a geometric series.

Input:
	firstElement  	- The first term of the series
	ratio			- The series common ratio
	numOfElements	- Number of elements of the series to be displayed
Output:
	None
*/
void geometricSeries(int firstElement, int ratio, int numOfElements)
{
	int ratioPowers = 1;
	int element = 0 ;
	
	for( element = 0 ; element < numOfElements ; element++ )
	{
		printf("%d ", firstElement * ratioPowers);
		ratioPowers *= ratio;
	}
	printf("\n");
}
