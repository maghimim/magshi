/*********************************
* Class: MAGSHIMIM C1			 *
* Week 6           				 *
* Homework solution   			 *
* Two maximal numbers			 *
**********************************/

#include <stdlib.h>
#include <stdio.h>

#define END_INPUT -999
#define FALSE 0
#define TRUE !FALSE

/**
The program repeatedly get numbers from the user until -999 is inserted.
It then prints to two biggest number that were entered.

Input:
	None
Output:
	The program returns 0 upon successful completion of its running (windows convention)
*/
int main(void)
{
	int num = 0;
	int firstMax = 0;
	int secondMax = 0;
	unsigned int counter = 1;

	// input
	printf("Enter number (%d to stop): ", END_INPUT);
	scanf("%d", &num);

	// loop until end of input
	while (num != END_INPUT)
	{
		// in case its first iteration should init firstMax variable
		if (counter == 1)
		{
			firstMax = num;
		}
		else if (counter == 2) // in case its second iteration should init secondMax variable
		{
			secondMax = num;
		}
		
		// check if the current number is bigger then the max number till now
		if (num > firstMax)
		{
			// set the max variables with new values
			secondMax = firstMax;
			firstMax = num;
		}
		else if ((counter > 2) && (num > secondMax)) // check if the current number is bigger then the second max number
		{
			// change the second max variable
			secondMax = num;
		}

		++counter;

		// input
		printf("Enter number (%d for end): ", END_INPUT);
		scanf("%d", &num);

	}

	printf("First max: %d, Second max: %d\n", firstMax, secondMax);

	return 0;
}