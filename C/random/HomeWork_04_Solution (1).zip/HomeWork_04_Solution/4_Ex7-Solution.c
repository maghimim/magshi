/*********************************
* Class: MAGSHIMIM C1			 *
* Week 4           				 *
* Question 7		  			 *
* The next day					 *
**********************************/

#include <stdio.h>
#include <stdlib.h>

#define MIN_DAY 1 
#define JAN 1
#define FEB 2
#define MAR 3 
#define APR 4
#define MAY 5
#define JUN 6
#define JUL 7
#define AUG 8
#define SEP 9
#define OCT 10
#define NOV 11
#define DEC 12

#define LONG_MONTH 31
#define SHORT_MONTH 30
#define FEB_MONTH 28

/**
This program gets a date from the user and prints the date of the next day

input: 
		None

output: The program returns 0 upon successful completion of its 
		running (windows convention)

*/
int main (void)
{
	unsigned int day = 0,month = 0,year = 0;

	//get input from the user
	printf("Please enter a date in the following form - dd.mm.yyyy\n");
	scanf("%2d.%2d.%4d",&day,&month,&year);

	//check validation of the given date
	if (((month == JAN || month == MAR || month == MAY || month == JUL || month == AUG || month == OCT || month == DEC) && day >= MIN_DAY && day <= LONG_MONTH) ||
		((month == APR || month == JUN || month == SEP || month == NOV) && day >= MIN_DAY && day <= SHORT_MONTH) ||
		(month == FEB && day >= MIN_DAY && day <= FEB_MONTH))
	{
		if (((month == JAN || month == MAR || month == MAY || month == JUL || month == AUG || month == OCT || month == DEC) && day == LONG_MONTH) ||
			((month == APR || month == JUN || month == SEP || month == NOV) && day == SHORT_MONTH) ||
			(month == FEB && day == FEB_MONTH))
		{
			//its the last day of the month
			day = 1;
			month++;
			if (month > DEC) //its the last day of the year
			{
				month = JAN;
				year++;
			}
		}
		else //its the middle of the month
		{
			day++;
		}
		printf("The date is valid\n");
		printf("The date is %02d.%02d.%04d\n",day,month,year);
	}
	else
	{
		printf("The date isn't valid\n");
	}

	return 0;
}
