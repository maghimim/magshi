#include <stdio.h>

int main(void)
{
	const int minAge = 16;
	const int maxAge = 18;
	int age = 0;
	
	printf("Please enter an age:\n");
	scanf("%d", &age);
	getchar();
	
	
	printf("age: %d\n", age);
	
	/*there are 4 mistakes in Daniel's code:
		1. the "!" operator was only on the right condition.
		2. the logical operator was wrong, he should have convert it too.
		3. the if-parentheses were missing
		4. no else statement 
	*/
	if(!(age >= minAge && age <= maxAge)){
		printf("Yay! your age is not between 16 and 18!\n");
		printf("You can have a phone!\n");
	}
	
	else{
		printf("Sorry, you have to study...\n");
	}

	return 0;
}
 
