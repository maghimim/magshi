#include <stdio.h>

int main(void)
{
	
	int number = 0;
	
	printf(" Please enter a number between 1 to 6:\n");
	scanf("%d", &number);
	getchar(); //cleaning the buffer
	
	switch(number){
		case 1:
			printf("one\n");
			break;
		case 2:
			printf(" two\n");
			break;
		case 3:
			printf("three\n");
			break;
		case 4:
			printf("four\n");
			break;
		case 5:
			printf("five\n");
			break;
		case 6:
			printf("six\n");
			break;
		default:
			printf("this is not a valid number!\n");
	}
		
	return 0;
}
 
