/*********************************
* Class: MAGSHIMIM C1			 *
* Week 4           				 *
* Class solution 4  			 *
**********************************/

#include <stdlib.h>
#include <stdio.h>

/**
The program includes some conditions

Input:
	None
Output:
	The program returns 0 upon successful completion of its running
*/
int main(void)
{
	// variables definition
	int var = 0;
	
	//condition that will never be TRUE includes ||
	if (0 || 0)
	{
		
	}

	//condition that will never be TRUE includes var
	if (var && !var)
	{

	}

	//condition that will always be TRUE 
	if (1) 
	{

	}

	//the second condition will never be checked because 0 is false
	if (0 && (var * 17 + 53 / 2))
	{

	}

	return 0;
} 