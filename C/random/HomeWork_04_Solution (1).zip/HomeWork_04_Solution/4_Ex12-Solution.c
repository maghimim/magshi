/*********************************
* Class: MAGSHIMIM C1			 *
* Week 4           				 *
* Question 11		  			 *
* Using ? for absolute value	 *
**********************************/

#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	// Get a number from the user
	int num = 0;
	printf("Please enter a number: ");
	scanf("%d", &num);

	printf("Absolute value is: ");
	
	num < 0 ? printf("%d", -num) : printf("%d", num);
	
	printf("\n");
	
	return 0;
}