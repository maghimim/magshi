/*********************************
* Class: MAGSHIMIM C2			 *
* Week 5           				 *
* HW solution 				 	 *
**********************************/

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define NAME_MAX_LENGTH 50

void myFgets(char str[], int n);
void getFriends(char** friends, int numOfFriends);
void sortFriends(char** friends, int numOfFriends);
void printFriends(char** friends, int numOfFriends);
void freeFriends(char** friends, int numOfFriends);


int main(void)
{	
	int numOfFriends = 0;
	char** friends = NULL;
		
	printf("Enter number of friends: ");
	scanf("%d", &numOfFriends);
	getchar(); // clean buffer
	
	friends = (char**)malloc(sizeof(char*) * numOfFriends); // allocate array of pointers to names
	if(!friends) // malloc check
	{
		printf("\nError allocating variables\n");
		return 1;
	}
	
	getFriends(friends, numOfFriends);
	sortFriends(friends, numOfFriends);
	printFriends(friends, numOfFriends);
	
	//freeing all allocated memory
	freeFriends(friends, numOfFriends);

	getchar();
	return 0;
}

/*
Function reads names of friends from user
input: array to read into, number of friends
output: none
*/
void getFriends(char** friends, int numOfFriends)
{
	char tempName[NAME_MAX_LENGTH] = {0};
	int i = 0;
	for(i = 0; i < numOfFriends; i++)
	{
		printf("Enter name of friend %d: ", i+1);
		myFgets(tempName, NAME_MAX_LENGTH);
		friends[i] = (char*)malloc(sizeof(char) * (strlen(tempName)+1));
		if(!friends[i])//if allocation failed
		{
			while(i) //free all previews successful allocations
			{
				i--;
				free(friends[i]);
			}
			free(friends);
			printf("\nError allocating variables\n");
			return;
		}
		strncpy(friends[i], tempName, strlen(tempName)+1);
	}
}

/*
Function sorts names of friends
input: array of friends, number of friends
output: none
*/
void sortFriends(char** friends, int numOfFriends)
{
	int i = 0, j = 0;
	char* temp = 0;
	
	for(i = 0; i < numOfFriends; i++) //bubble sort strings
	{
		for(j = 0; j < numOfFriends-1; j++)
		{
			if (strcmp(friends[j], friends[i]) > 0) //dictionary comparison
			{
				//pointers swap
				temp = friends[i];
				friends[i] = friends[j];
				friends[j] = temp;
			}
		}
	}
}

/*
Function prints names of friends
input: array of friends, number of friends
output: none
*/
void printFriends(char** friends, int numOfFriends)
{
	int i = 0;
	for(i = 0; i < numOfFriends; i++)
	{
		printf("Friend %d: %s\n",i+1, friends[i]); //print names in abc order
	}
}


/*
Function frees memory of friends
input: array of friends, number of friends
output: none
*/
void freeFriends(char** friends, int numOfFriends)
{
	int i = 0;	
	for(i = 0; i < numOfFriends; i++)
	{
		free(friends[i]);
	}
	free(friends);
}


/*
Function will perform the fgets command and also remove the newline 
that might be at the end of the string - a known issue with fgets.
input: the buffer to read into, the number of chars to read
*/
void myFgets(char str[], int n)
{
	fgets(str, n, stdin);
	str[strcspn(str, "\n")] = 0;
}
