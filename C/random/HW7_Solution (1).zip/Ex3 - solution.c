/*********************************
* Class: MAGSHIMIM C2			 *
* Week 7          				 *
* HW solution	 			 	 *
**********************************/

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

#define PARAMS_NO 4 //number of parameters
#define TYPE_PARAM 1
#define PARAM_SOURCE 2
#define PARAM_DEST 3

#define TEXT_COPY "textCopy"
#define BIN_COPY "binaryCopy"

#define CHUNK_SIZE 1024

#define READ_MODE 0
#define WRITE_MODE 1

//these two will be used with these two arrays:
char* textModes[] = { "r", "w" };
char* binModes[] = { "rb", "wb" };

void textCopy(FILE* src, FILE* destFilename);
void binaryCopy(FILE* src, FILE* dst);

int main(int argc, char* argv[])
{
	char* sourceFilename = NULL;
	char* destFilename = NULL;
	char ** modes = 0;
	int num = 0;
	FILE* src = NULL;
	FILE* dst = NULL;
	void(*copyFunc)(FILE*, FILE*); // using pointer-to-fuction. Can read about it here: https://stackoverflow.com/questions/840501/how-do-function-pointers-in-c-work
	

	if (argc != PARAMS_NO)
	{
		printf("Invalid execution.\n");
		printf("Usage: %s (textCopy|binaryCopy) <sourceFilename_filename> <destFilenameination_filename>\n", argv[0]);
		return (-1); //error wrong parameters
	}

	if (strcmp(argv[TYPE_PARAM], TEXT_COPY) == 0)
	{
		modes = textModes;
		copyFunc = textCopy; // pointer-to-function
	}
	else if (strcmp(argv[TYPE_PARAM], BIN_COPY) == 0)
	{
		modes = binModes;
		copyFunc = binaryCopy; // pointer-to-function
	}
	else
	{
		printf("Invalid execution.\n");
		printf("Usage: %s (textCopy|binaryCopy) <sourceFilename_filename> <destFilenameination_filename>\n", argv[0]);
		return -1; //error wrong parameters
	}
	
	sourceFilename = argv[PARAM_SOURCE];
	destFilename = argv[PARAM_DEST];

	// Open sourceFilename file for reading.
	src = fopen(sourceFilename, modes[READ_MODE]);
	if (!src)
	{
		printf("%s file does not exist.\n", sourceFilename);
		return -1; //error opening source file.
	}

	// Check if destFilenameination file already exists. Open destFilenameination file for reading(!).
	dst = fopen(destFilename, modes[READ_MODE]);

	// Destination file does not exists (dst = NULL), can copy file to a new file.
	if (!dst)
	{
		dst = fopen(destFilename, modes[WRITE_MODE]);
		if (!dst)
		{
			printf("Error opening %s file.\n", destFilename);
			return -1; //error opening destination file.
		}

		//copy file
		// we used pointer-to-function.
		copyFunc(src, dst);
		// if we don't want to use pointer-to-function, we could erase all the lines above which a comment "pointer-to-fuction"
		// and here have this code:
		/*
		if(strcmp(argv[TYPE_PARAM], TEXT_COPY) == 0)
		{
			textCopy(src,dst);
		}
		else
		{
			binaryCopy(src,dst);
		}
		*/
		fclose(dst);
	}

	// Destination file exists, ask user what to do.
	else
	{
		// Close the old file (will be re-open for writing later)
		fclose(dst);
		printf("Do you want to overwrite? 0 (no) / 1 (yes)\n");
		scanf("%d", &num);
	
		if (num)
		{
			// User approved, copy files
			dst = fopen(destFilename, modes[WRITE_MODE]);
			if (!dst)
			{
				printf("Error creating %s file.\n", destFilename);
				return -1; //error creating destination file
			}
			copyFunc(src, dst);
			fclose(dst);
		}
	}

	// Close the sourceFilename file
	fclose(src);
	return 0; //successful end of program
}

/**
Copy a text file.

Input:
src - This is the file being copied.
destFilename - This is the destFilenameination file.
*/
void textCopy(FILE* src, FILE* dst)
{
	char ch = ' ';
	while ((ch = fgetc(src)) != EOF)
	{
		fputc(ch, dst);
	}
	printf("Copy completed\n");
}


/**
Copy a binary file.

Input:
src - This is the file being copied.
destFilename - This is the destFilenameination file.
*/
void binaryCopy(FILE* src, FILE* dst)
{
	char buffer[CHUNK_SIZE] = { 0 };
	size_t numBytesRead = 0;
	while (!feof(src))
	{
		numBytesRead = fread(buffer, sizeof(char), CHUNK_SIZE, src);
		fwrite(buffer, sizeof(char), numBytesRead, dst);
	}
	printf("Copy completed\n");
}