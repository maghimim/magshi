
/************************************\
|*			MAGSHIMIM				*|
|*		Week 7 - CSV Question 		*|
\************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>


#define MAX_VALUE_SIZE 25
#define SEARCH_OP 1
#define CHANGE_OP 2
#define COPY_OP 3
#define EXIT_OP 4

#define NUM_PARAMS 2
#define FILE_PARAM 1

int menu(void);
int searchFile(const char *searchStr, FILE *inputFile);
int changeValue(int Row, int Col, const char *changeStr, FILE *inputFile);
int copyValue(int originalRow, int orginalCol, int destinationRow, int destinationCol, FILE *inputFile);
void myFgets(char str[], int n);

int main(int argc, char *argv[])
{
	FILE *inputFile = NULL;
	char term[MAX_VALUE_SIZE] = { 0 };
	int row = 0;
	int col = 0;
	int row2 = 0;
	int col2 = 0; // row2, col2 - used for destination of copy in copy function (option 3).
	int retRow = 0;
	int op = 0;
	
	if(argc != NUM_PARAMS)
	{
		printf("Usage: %s <csv file path>\n", argv[0]);
		return -1;
	}

	while (op != EXIT_OP)
	{
		op = menu();
		switch (op)
		{
		case SEARCH_OP:
			inputFile = fopen(argv[FILE_PARAM], "rt");
			if (!inputFile)
			{
				printf("Error opening file!\n");
				return -1; //Error opening file.
			}
			fflush(stdin);
			printf("Enter value to search: ");
			myFgets(term, MAX_VALUE_SIZE);
			retRow = searchFile(term, inputFile);
			retRow ? printf("Value was found in row %d\n", retRow) : printf("Value Wasn't Found\n");
			//close file and check.
			if (fclose(inputFile) == EOF)
			{
				printf("An Error occurred closing file");
				return -1;
			}
			break;

		case CHANGE_OP:
			inputFile = fopen(argv[FILE_PARAM], "r+t");
			if (!inputFile)
			{
				printf("Error opening file!\n");
				return -1; //Error opening file.
			}
			printf("Enter row number: ");
			scanf("%d", &row);
			printf("Enter column number: ");
			scanf("%d", &col);
			fflush(stdin);
			printf("Enter new value: ");
			myFgets(term, MAX_VALUE_SIZE);
			retRow = changeValue(row, col, term, inputFile);

			retRow != EOF && fclose(inputFile) != EOF ? printf("A change was made in row %d\n", retRow) : printf("An error ocurred!\n"); //check changed values and closing of file

			break;

		case COPY_OP:
			inputFile = fopen(argv[FILE_PARAM], "r+t");
			if (!inputFile)
			{
				printf("Error opening file!\n");
				return -1; //Error opening file.
			}
			printf("Enter source row: ");
			scanf("%d", &row);
			printf("Enter source column: ");
			scanf("%d", &col);
			printf("Enter destination row: ");
			scanf("%d", &row2);
			printf("Enter destination column: ");
			scanf("%d", &col2);
			retRow = copyValue(row, col, row2, col2, inputFile);
			(retRow != EOF  &&  fclose(inputFile) != EOF) ? printf("Change was made successfully\n") : printf("An error occurred!\n");

			break;
		case EXIT_OP:
			printf("Goodbye!\n");
			break;
		default:
			printf("Try again.\n");
		}
	}

	argc = argc;
	getchar(); //pause program to view screen.
	return 0;
}


/*
displays menu to user and gets user choice
input:
none.
output:
success - number of selection - 1: Search File, 2: Change Value, 3: Copy Value.
error - any other number.
*/
int menu(void)
{
	int choice = 0;
	printf("Please enter your choice:\n");
	printf("%d - Search a term in the document.\n", SEARCH_OP);
	printf("%d - change a value in a specific place.\n", CHANGE_OP);
	printf("%d - copy a value from one place to another\n", COPY_OP);
	printf("%d - Exit\n", EXIT_OP);
	scanf("%d", &choice);
    getchar();
	return choice;
}

/*
search for a term in the file.
input:
searchStr - pointer to string of the term to search.
inputFile - FILE structure pointer for CSV file to be checked.
output:
success - number of row the term was found at.
error - (not found) 0.
*/
int searchFile(const char *searchStr, FILE *inputFile)
{
	char currWord[MAX_VALUE_SIZE];
	int i = 0;
	int row = 0;
	int foundFlag = 0;
	int eofFlag = 0;
	for (i = 0; !foundFlag && !eofFlag; i++)
	{
		currWord[i] = (char)fgetc(inputFile);
		if (currWord[i] == ',')
		{
			//check is last word is the search string
			currWord[i] = 0;
			if (!strcmp(searchStr, currWord))
			{
				foundFlag = 1;
			}
			//reset the word counter for next iteration
			i = -1;
		}
		else if (currWord[i] == '\n')
		{

			//check is last word is the search string
			currWord[i] = 0;
			if (!strcmp(searchStr, currWord))
			{
				foundFlag = 1; // set the found Flag
			}

			else
			{
				row++; //increment row counter 
			}

			//reset the word counter for next iteration
			i = -1;
		}
		else if (currWord[i] == EOF)
		{
			//check is last word in the file is the search string
			currWord[i] = 0;
			if (!strcmp(searchStr, currWord))
			{
				foundFlag = 1; // set the found Flag
			}
			eofFlag = 1; // set the EOF Flag
		}
	}

	return ((row + 1)*foundFlag); // return 0 in case the search term was not found.	
}

/*
change a specific value in the file.
input:
row - value number of row.
col - value number of column.
changeStr - pointer to string of the new term to replace the old one.
inputFile - FILE structure pointer for CSV file to be changed.
output:
success - number of characters changed in file.
Error - EOF.
*/
int changeValue(int Row, int Col, const char *changeStr, FILE *inputFile)
{
	int i = 0;
	int changeStrLen = strlen(changeStr);
	//skip rows
	for (i = 1; i < Row; i++)
	{
		while (fgetc(inputFile) != '\n');
	}
	//skip columns
	for (i = 1; i < Col; i++)
	{
		while (fgetc(inputFile) != ',');
	}

	//change word
	for (i = 0; i < changeStrLen; i++)
	{
		fseek(inputFile, 0, SEEK_CUR); // needed before writing to file with fputc, other easier solution would be using fputs or fprintf
		if (fputc(changeStr[i], inputFile) == EOF)
		{
			return EOF;// Error writing to file
		}
	}
	return i;
}

/*
copy a specific value in the file from one place to another.
input:
originalRow - value number of the row to be copied.
orginalCol - value number of the column to be copied.
destinationRow - value number of the row to be deleted and changed to value in originalROW and orginalCol.
destinationCol - value number of the column to be deleted and changed to value in originalROW and orginalCol.
inputFile - FILE structure pointer for CSV file to be changed.
output:
success - number of characters changed in file.
Error - EOF.
*/
int copyValue(int originalRow, int orginalCol, int destinationRow, int destinationCol, FILE *inputFile)
{
	int i = 0;
	int changeStrLen = 0;
	char wordToCopy[MAX_VALUE_SIZE];
	char checkChar = 0; //assign a value so no garbage value on first check

	//find first word and save it to a string
	//skip rows
	for (i = 1; i < originalRow; i++)
	{
		while (fgetc(inputFile) != '\n');
	}
	//skip columns
	for (i = 1; i < orginalCol; i++)
	{
		while (fgetc(inputFile) != ',');
	}
	//save to wordToCopy
	for (i = 0; checkChar != ',' && checkChar != '\n' && checkChar != EOF; i++)
	{
		wordToCopy[i] = (char)fgetc(inputFile);
		checkChar = wordToCopy[i];
	}
	wordToCopy[i - 1] = 0; // set null terminator at end of string.
	printf("Value to copy: %s\n", wordToCopy);
	//reset file location pointer to start of file.
	fseek(inputFile, 0, SEEK_SET);


	//find second word and copy string to it's location
	//skip rows
	for (i = 1; i < destinationRow; i++)
	{
		while (fgetc(inputFile) != '\n');
	}
	//skip columns
	for (i = 1; i < destinationCol; i++)
	{
		while (fgetc(inputFile) != ',');
	}
	//copy word to file
	changeStrLen = strlen(wordToCopy);
	for (i = 0; i < changeStrLen; i++)
	{
		fseek(inputFile, 0, SEEK_CUR);
		if (fputc(wordToCopy[i], inputFile) == EOF)
		{
			return EOF; //Error changing file
		}
	}

	return i;
}

/*
Function will perform the fgets command and also remove the newline 
that might be at the end of the string - a known issue with fgets.
input: the buffer to read into, the number of chars to read
*/
void myFgets(char str[], int n)
{
	fgets(str, n, stdin);
	str[strcspn(str, "\n")] = 0;
}
