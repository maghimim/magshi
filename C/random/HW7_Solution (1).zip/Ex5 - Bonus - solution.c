/*********************************
* Class: MAGSHIMIM C2			 *
* Week 10          				 *
* HW solution (BONUS)		 	 *
**********************************/
#include <stdio.h>

#define PLAINTEXT_FILENAME "The Princess Bride.txt"
#define CODEBOOK_FILENAME "Starwars.txt"
#define CODES_FILENAME "password.txt"
#define CIPHERTEXT_FILENAME "enc_Starwars.txt"

typedef unsigned char BYTE;

void closeFile(FILE *pfile);
void encrypt(FILE *plaintext, FILE *codebook, FILE *codes, FILE *ciphertext);

int main(int argc, char **argv)
{
	FILE *plaintext = NULL;			// Will point on the file we want to encrypt("The Princess Bride.txt")
	FILE *codebook = NULL;				// The file used for the encryption ("Starwars.txt")
	FILE *codes = NULL;				// The file with the numbers indicating where to go in the codebook ("password.txt")
	FILE *ciphertext = NULL;			// The file which will keep the results;
	
	plaintext = fopen(PLAINTEXT_FILENAME, "rb");	// Read as binary so we don't ignore the 0x0D bytes
	codebook = fopen(CODEBOOK_FILENAME, "rb");		// Must be binary for using fseek
	codes = fopen(CODES_FILENAME, "rt");			// Read as text so we can call fscanf
	ciphertext = fopen(CIPHERTEXT_FILENAME, "wb");	// Write as binary so we don't ignore the 0x0D bytes
	
	if(plaintext == NULL || codebook == NULL || codes == NULL || ciphertext == NULL)
	{
		closeFile(plaintext);
		closeFile(codebook);
		closeFile(codes);
		closeFile(ciphertext);
		printf("Error opening files\n");
	}
	else
	{
		encrypt(plaintext, codebook, codes, ciphertext);
		closeFile(plaintext);
		closeFile(codebook);
		closeFile(codes);
		closeFile(ciphertext);
	}
	
	return 0;
}

/**
A function used to close an open file. Will ignore the case the file is a NULL pointer.
*/
void closeFile(FILE *pfile)
{
	if(pfile != NULL)
	{
		fclose(pfile);
	}
}

/**
Encrypt the plaintext using the algorithm from the exercise.
*/
void encrypt(FILE *plaintext, FILE *codebook, FILE *codes, FILE *ciphertext)
{
	unsigned int code = 0;
	BYTE codeByte = 0, plainByte = 0;
	int i = 0;
	
	// Read the byte from the plain text (for first iteration)
	plainByte = fgetc(plaintext);
	while(!feof(plaintext) && i < i+1)
	{
		// Read the code number from password.txt
		fscanf(codes,"%u",&code);
		// Set the position indicator according to the code number
		// and read the byte written there.
		fseek(codebook, code, SEEK_SET);
		codeByte = fgetc(codebook);
		// Write the XOR of bytes the the cipher-text file
		fputc(plainByte^codeByte,ciphertext);
		
		// Read the byte from the plain text (for next iteration)
		plainByte = fgetc(plaintext);
	}
}
