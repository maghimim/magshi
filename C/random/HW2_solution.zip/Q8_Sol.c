/*********************************
* Class: MAGSHIMIM C2			 *
* Week 2           				 *
* HW solution   			 	 *
**********************************/
#include <stdio.h>

void swap(float* x, float* y);
void sort3(float* num1, float* num2, float* num3);

int main(void)
{
	float num1 = 0, num2 = 0, num3 = 0;
	printf("Please enter num1, num2, num3: ");
	scanf("%f %f %f", &num1, &num2, &num3);
	
	sort3(&num1, &num2, &num3);
	printf("After sorting: num1 = %.2f num2 = %.2f num3 = %.2f \n", num1, num2, num3);
	getchar();
	getchar();
	return 0;
}

/*
Function makes a swap between the values of two numbers. 
input: the numbers to swap
output: none
*/
void swap(float* x, float* y) 
{ 
	float temp = *x; 
	*x = *y; 
	*y = temp; 
}


/*
Functions sorts three numbers.
input: the numbers
output: none
*/
void sort3(float* num1, float* num2, float* num3)
{
	int i = 0;
	// Bubble sort:
	for ( i = 0 ; i < 2 ; i++)
	{
		if (*num1 > *num2)
		{
			swap(num1, num2);
		}
		if (*num2 > *num3)
		{
			swap(num2, num3);
		}
	}
}
