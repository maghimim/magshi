/*********************************
* Class: MAGSHIMIM C2			 *
* Week 2           				 *
* HW solution  				 	 *
**********************************/

#include <stdio.h>
#include <stdlib.h>


int main(void)
{
	int * p = NULL;
	
	// The value of NULL is defined in stdlib to be zero
	// so the value of the pointer p is zero (i.e., the address 0).
	printf("%p", p);  // prints 0
	
	// The address 0 contains nothing, always. When we try to go there
	// the operating system know we are doing something wrong and stops
	// the program. This is also called null pointer exception.
	printf("%d", *p); // null pointer exception, causes program termination (CRASH)
	getchar();
	return 0;
}

