/*********************************
* Class: MAGSHIMIM C2			 *
* Week 2           				 *
* HW solution 			 		 *
**********************************/

#include <stdio.h>

void add(int* x, int* y, int* sum);

/*Bonus: tell about a way to debug the code, check the warnings etc.*/

int main(void)
{
	int a = 0, b = 0, sum = 0;
	int *c = &b; //missing a '&'
	printf("Enter two numbers: ");
	scanf("%d %d", &a, &b);
	getchar();
	add(&a, c, &sum); // extra '&'
	printf("The sum of a and b is: %d", sum);
	getchar();
	return 0;
}


void add(int* x, int* y, int* sum)
{
	*sum = *x + *y; // missing '*' 
}
