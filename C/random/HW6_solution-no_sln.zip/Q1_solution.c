/*********************************
* Class: MAGSHIMIM C2			 *
* Week 6           				 *
* HW Solution 					 *
**********************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define STR_LEN 30
#define FALSE 0
#define TRUE !FALSE

typedef struct animal
{
	char type[STR_LEN];
	char name[STR_LEN];
	int age;
} animal;

//Function declaration
void myFgets(char str[], int n);
void printAnimal(animal a);
int animalCmp(animal a1, animal a2);


int main(void)
{
	// could have done this with a loop (animal array).
	// but wanted to show explicitly how it looks:
	animal a1 = {{0}, {0}, 0};
	animal a2 = {{0}, {0}, 0}; 
	
	printf("First Animal\n");
	printf("Enter animal type: ");
	myFgets(a1.type, STR_LEN);
	printf("Enter animal name: ");
	myFgets(a1.name, STR_LEN);
	printf("Enter animal age: ");
	scanf("%d", &a1.age);
	getchar(); // clean buffer
	
	printf("Second Animal\n");
	printf("Enter animal type: ");
	myFgets(a2.type, STR_LEN);
	printf("Enter animal name: ");
	myFgets(a2.name, STR_LEN);
	printf("Enter animal age: ");
	scanf("%d", &a2.age);
	getchar(); // clean buffer
	
	printAnimal(a1);
	printAnimal(a2);
	
	animalCmp(a1, a2) ? printf("Same Animal\n") : printf("Different Animals\n");
	
	printf("sizeof(struct animal) = %d", sizeof(struct animal));
	
	getchar();
	return 0;
}

/*
Function will perform the fgets command and also remove the newline 
that might be at the end of the string - a known issue with fgets.
input: the buffer to read into, the number of chars to read
*/
void myFgets(char str[], int n)
{
	fgets(str, n, stdin);
	str[strcspn(str, "\n")] = 0;
}

/*
Function prints an animal's details
input: the animal to print
output: none
*/
void printAnimal(animal a)
{
	printf("%s is a %s, %d years old\n", a.name, a.type, a.age);
}

/*
Function compares animals - are they the same? 
input: the two animals
output: positive number if the animals are the same. zero otherwise. 
*/
int animalCmp(animal a1, animal a2)
{
	int equal = FALSE;
	equal = !strcmp(a1.type, a2.type) &&
			!strcmp(a1.name, a2. name) &&
			(a1.age == a2.age);
	return equal;
}