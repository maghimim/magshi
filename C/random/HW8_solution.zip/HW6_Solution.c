/*********************************
* Class: MAGSHIMIM C1			 *
* Week 8           				 *
* Homework solution			 *
**********************************/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int areValidNumbers(int num1,int num2, int num3);

int main(void)
{
	int num1 = 0;
	int num2 = 0;
	int num3 = 0;
	const int RANGE = 101;
	int valid = 0;
	
	srand (time(NULL));
	do
	{
		num1 = rand() % RANGE;
		num2 = rand() % RANGE;
		num3 = rand() % RANGE;
		valid = areValidNumbers(num1,num2,num3);
	} while(!valid);
	
	printf("The numbers are: %d %d %d\n", num1, num2, num3);
	 
	return 0;
}

/*
Function checks if 3 numbers are valid - one is even, another is odd, and at least one is at least 50
input: the numbers
output: 1 if they are valid, 0 otherwise
*/
int areValidNumbers(int num1, int num2, int num3)
{
	int ans = 0;
	const int EVEN = 2;
	const int MIN = 50;
	if (num1 % EVEN == 0 || num2 % EVEN == 0 || num3 % EVEN == 0)
	{
		if (num1 % EVEN != 0 || num2 % EVEN != 0 || num3 % EVEN != 0)
		{
			if (num1 >= MIN  || num2 >= MIN  || num3 >= MIN )
			{
				ans = 1;
			}
		}
	}
	return ans;
}
