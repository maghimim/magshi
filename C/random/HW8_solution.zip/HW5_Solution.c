/*********************************
* Class: MAGSHIMIM C1			 *
* Week 8           				 *
* Homework solution 			 *
**********************************/

#include <stdlib.h>
#include <stdio.h>

#define FALSE 0
#define TRUE !FALSE
#define WEEK_LENGTH 7
#define FEB_DAYS 28
#define SHORT_MONTH_DAYS 30
#define LONG_MONTH_DAYS 31

enum weekDay
{
	sunday = 1,
	monday,
	tuesday,
	wednesday,
	thursday,
	friday,
	saturday
};

enum month
{
	january = 1,
	february,
	march,
	april,
	may,
	june,
	july,
	august,
	september,
	october,
	november,
	december
};

int checkInput(enum month inputMonth, int day);
enum weekDay calcDay(enum weekDay firstOfMonth, int dayToCheck);
void printWeekDayName(enum weekDay numDay);

/**
The main function of the program. 
*/
int main (void)
{
	enum month monthToCheck = 0;
	enum weekDay firstOfMonth = 0;
	int dayToCheck = 0, valid = TRUE;
	enum weekDay result = 0;
	
	printf("Hello! Welcome to the day calculator!\n");
	do
	{
		printf("Enter month to check: (1-Jan, 2-Feb, etc) ");
		scanf("%d", &monthToCheck);
		printf("Enter day to check: ");
		scanf("%d", &dayToCheck);
		valid = checkInput(monthToCheck, dayToCheck);
		if(!valid)
		{
			printf("Invalid input, try again\n");
		}
	}
	while(!valid);
	
	do
	{
		printf("Enter the weekday of the 1st of the month: (1-Sunday, 2-Monday, etc) ");
		scanf("%d", &firstOfMonth);
		if(!valid)
		{
			printf("Invalid input, try again\n");
		}
	}
	while(!(firstOfMonth >= sunday && firstOfMonth <= saturday));
	
	result = calcDay(firstOfMonth, dayToCheck);
	
	printf("The %d.%d will be a ", dayToCheck, monthToCheck);
	printWeekDayName(result);
	
	return 0;
}

/*
Function checks if day is in month (e.g: 31 is in December, but not in November).
input: day and month to check
output: if the day is in the month
*/
int checkInput(enum month inputMonth, int day)
{
	int valid = TRUE;
	if(day < 1 || day > LONG_MONTH_DAYS) 
	{
		valid = FALSE;
	}
	else if(inputMonth < january || inputMonth > december)
	{
		valid = FALSE;
	}
	else if(inputMonth == february && day > FEB_DAYS)
	{
		valid = FALSE;
	}
	else if((inputMonth == april || inputMonth == june || inputMonth == september || inputMonth == november) &&
				day > SHORT_MONTH_DAYS)
	{
		valid = FALSE;
	}
	return valid;
}

/*
Function will tell which day of the week a specific day will be.
input: the weekday of the first day of the month, the day to check
output: the weekday of the day to check
*/
enum weekDay calcDay(enum weekDay firstOfMonth, int dayToCheck)
{
	// maybe there is a simpler way?
	enum weekDay result = (dayToCheck + (firstOfMonth - 1)) % WEEK_LENGTH;
	if(result == 0)
	{
		result = saturday;
	}
	return result;
}

/*
Function will print the name of the day
input: number of day to print
output: none
*/
void printWeekDayName(enum weekDay numDay)
{
	switch(numDay)
	{
		case(sunday):
			printf("Sunday");
			break;
		case(monday):
			printf("Monday");
			break;
		case(tuesday):
			printf("Tuesday");
			break;
		case(wednesday):
			printf("Wednesday");
			break;
		case(thursday):
			printf("Thursday");
			break;
		case(friday):
			printf("Friday");
			break;
		case(saturday):
			printf("Saturday");
			break;
		default: 
			printf("---");
			break;
	}
}