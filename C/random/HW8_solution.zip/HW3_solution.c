/*********************************
* Class: MAGSHIMIM C1			 *
* Week 8           				 *
* HOMEWORK solution  			 *
**********************************/

#include <stdio.h>
#include <stdlib.h>


/* 
b. why enum?
	1. a much more orgnized and easy to read code (improved program readability).
	2. lower maintenance requirement: easier to define constants (automatic enumaration).
	3. better debugging capability: most debuggers cannot print #define values, 
	but can print the value of an enumeration constant. 

c. just make an assignment... if a value was not specified for a variable, 
its value will be the same as the previous variable's value + 1.

d. enum examples:
	1. enum week {sunday, monday, tuesday, wednesday, thursday, friday, saturday};
	2. enum pixel {red, green, blue};
	3. enum designText {ITALICS, BOLD, UNDERLINE};
	4. enum suit {club, diamonds, hearts, spades};
} 
etc.

*/
enum difficultyLevel
{
	easy = 1,
	normal,
	hard,
	go_bananas,
	crazy
};

int printDifficultyMenu(void);
void printChoice(int choice);
void runGame(int choice);

int main(void)
{
	int choice = 0;
	
	// difficulty menu
	printDifficultyMenu();

	scanf("%d", &choice);
	printChoice(choice);
	
	runGame(choice);
	
	return 0;
}

/*
The function prints the possible difficulty levels.
input: the character to encode, the code (a number).
output: the encoded character
*/
int printDifficultyMenu()
{
	printf("Please choose a difficulty level: \n");
	printf("1 - easy\n");
	printf("2 - normal\n");
	printf("3 - hard\n");
	printf("4 - go bananas\n");
	printf("5 - crazy\n");
}

/*
The function prints the user's choice.
input: the character to encode, the code (a number).
output: the encoded character
*/
void printChoice(int choice)
{
	printf("You chose to play in ");
	switch(choice)
	{
		case easy:
			printf("easy");
			break;
		case normal:
			printf("normal");
			break;
		case hard:
			printf("hard");
			break;
		case go_bananas:
			printf("go_bananas");
			break;
		case crazy:
			printf("crazy");
			break;
		default:
			printf("a non existing");
	}
	printf(" mode.\n");
}


/*
The function does nothing.
input: the character to encode, the code (a number).
output: the encoded character
*/
void runGame(int choice)
{
	//printf("This is a game.");
}
