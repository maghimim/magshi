/*********************************
* Class: MAGSHIMIM C2			 *
* Week 1           				 *
* HW solution 2  			 	 *
**********************************/

#include<stdio.h>
#include<string.h>

#define X_WIN	1
#define O_WIN	-1
#define TIE		0
#define X_CHAR 'x'
#define O_CHAR 'o'
#define BLANK ' '
#define FALSE 0
#define TRUE !FALSE

#define BOARD_SIZE 3

void getInput(char board[][BOARD_SIZE], char turn);
int checkTicTacToe(char board[][BOARD_SIZE]);
void printBoard(char board[][BOARD_SIZE]);



int main(void)
{
	char xoBoard[BOARD_SIZE][BOARD_SIZE] = { { BLANK, BLANK, BLANK },
	{ BLANK, BLANK, BLANK },
	{ BLANK, BLANK, BLANK } };

	char xoArr[] = { X_CHAR, O_CHAR }; // global var used to alternate between turns
	int winner = TIE;
	int turnCount = 0;
	char turnChar = ' ';

	while (winner == TIE && turnCount < BOARD_SIZE*BOARD_SIZE)
	{
		turnChar = xoArr[turnCount++ % 2]; // use count then increase it
		printf("It is %c's turn.\n", turnChar);
		getInput(xoBoard, turnChar);
		printBoard(xoBoard);
		winner = checkTicTacToe(xoBoard);
	}

	if (winner == X_WIN)
	{
		printf("X is the winner!\n");
	}
	else if (winner == O_WIN)
	{
		printf("O is the winner!\n");
	}
	else
	{
		printf("Tie!\n");
	}
	getchar();
	getchar();
	return 0;
}

/*
The function receives a board of tic-tac-toe of size BOARD_SIZE x BOARD_SIZE,
it checks if one of the players won the board, and return value accordingly.

Input:
board - A 2D-array of chars containing only 'o','x',' '.
Output:
(+1) if 'x' won, (-1) if 'o' won, (0) if nobody won / the game is not over
*/
int checkTicTacToe(char board[][BOARD_SIZE])
{
	int line = 0, winner = 0;
	if ((board[1][1] != BLANK) &&
		((board[0][0] == board[1][1] && board[0][0] == board[2][2]) ||
		(board[0][2] == board[1][1] && board[0][2] == board[2][0])))
	{
		if (board[1][1] == X_CHAR)
		{
			winner = X_WIN;
		}
		else
		{
			winner = O_WIN;
		}
	}
	else
	{
		for (line = 0; line < BOARD_SIZE && winner == TIE; line++)
		{
			if (board[line][0] != BLANK &&
				board[line][0] == board[line][1] && board[line][0] == board[line][2])
			{
				if (board[line][0] == X_CHAR)
				{
					winner = X_WIN;
				}
				else
				{
					winner = O_WIN;
				}
			}
			else if (board[0][line] != BLANK &&
				board[0][line] == board[1][line] && board[0][line] == board[2][line])
			{
				if (board[0][line] == X_CHAR)
				{
					winner = X_WIN;
				}
				else
				{
					winner = O_WIN;
				}
			}
		}
	}
	return winner;
}

/*
Get user input for the tic-tac-toe board
input: the board
*/
void getInput(char board[][BOARD_SIZE], char turn)
{
	int i = 0, j = 0;
	int played = FALSE;
	do
	{
		printf("Enter location on board: ");
		scanf("%d %d", &i, &j);
		if (board[i][j] == BLANK)
		{
			board[i][j] = turn;
			played = TRUE;
		}
		else
		{
			printf("Location taken! Try again\n");
		}
	} while (!played);
}

/*
Function will print the board.
input: the board to print
*/
void printBoard(char board[][BOARD_SIZE])
{
	int i = 0, j = 0;
	for (i = 0; i < BOARD_SIZE; i++)
	{
		for (j = 0; j < BOARD_SIZE; j++)
		{

			printf("%3c", board[i][j]);
		}
		printf("\n");
	}
	printf("\n");
}