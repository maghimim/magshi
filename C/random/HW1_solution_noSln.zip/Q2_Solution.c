/*********************************
* Class: MAGSHIMIM C2			 *
* Week 1           				 *
* HW solution 1  			 	 *
**********************************/

#include<stdio.h>
#include<string.h>

#define STR_LEN 20
#define LITTLE_A_CHAR 'a'
#define LITTLE_Z_CHAR 'z'
#define BIG_A_CHAR 'A'
#define BIG_Z_CHAR 'Z'

void myFgets(char str[], int n);

int main(void)
{
	char str[STR_LEN] = { 0 };
	char smallStr[STR_LEN] = { 0 }, bigStr[STR_LEN] = { 0 };
	int ind = 0, sInd = 0, bInd = 0;

	printf("Enter a string with upper and lower case letters: ");
	myFgets(str, STR_LEN);

	for (ind = 0; ind < (int)strlen(str); ind++)
	{
		if (str[ind] >= LITTLE_A_CHAR && str[ind] <= LITTLE_Z_CHAR)
		{
			smallStr[sInd] = str[ind];
			sInd++;
		}
		else if (str[ind] >= BIG_A_CHAR && str[ind] <= BIG_Z_CHAR)
		{
			bigStr[bInd] = str[ind];
			bInd++;
		}
	}
	// Assign NULL termination to the end of the strings
	smallStr[sInd] = 0;
	bigStr[bInd] = 0;
	// Print them
	printf("The upper and lower case words: \n");
	puts(bigStr);
	puts(smallStr);
	getchar();
	return 0;
}


/*
Function will perform the fgets command and also remove the newline
that might be at the end of the string - a known issue with fgets.
input: the buffer to read into, the number of chars to read
*/
void myFgets(char str[], int n)
{
	fgets(str, n, stdin);
	str[strcspn(str, "\n")] = 0;
}
