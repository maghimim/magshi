/*********************************
* Class: MAGSHIMIM C2			 *
* Week 1           				 *
* HW solution 5  			 	 *
**********************************/

#include <stdio.h>
#include <string.h>

#define STR_LEN 20

unsigned int myStrcspn(const char str1[], const char str2[]);
void myFgets(char str[], int n);

int main(void)
{
	char str[STR_LEN] = {0};
	char keys[STR_LEN] = {0};
	int i = 0;
	printf("Please enter the string: ");
	myFgets(str, STR_LEN);
	printf("Please enter the keys: ");
	myFgets(keys, STR_LEN);

	i = strcspn(str, keys);
	printf("The index of the first key in the string is %d.\n", i);
	return 0;
}

/**
Get span until character in string.

Scans str1 for the first occurrence of any of the characters that are part of str2,
returning the number of characters of str1 read before this first occurrence.

The search includes the terminating null-characters. Therefore, the function will
return the length of str1 if none of the characters of str2 are found in str1.

Input:
str1 - C string to be scanned.
str2 - C string containing the characters to match.

Output:
The length of the initial part of str1 not containing any of the characters
that are part of str2. This is the length of str1 if none of the characters
in str2 are found in str1.

*/
unsigned int myStrcspn(const char str1[], const char str2[])
{
	int i = 0, j = 0, found = 0;
	for (i = 0; i <= (int)strlen(str1) && !found; i++) // Note the <= (smaller-equal) we need to count for the null-character
	{
		// The second loop has to be on str2, since we want to 
		// check if any of the character of str2 is located
		// at the i-th place of str1
		for (j = 0; j <= (int)strlen(str2) && !found; j++) 		 // Again we use <=
		{
			if (str1[i] == str2[i])
			{
				found = 1;
			}
		}
	}
	return i;
}


/*
Function will perform the fgets command and also remove the newline 
that might be at the end of the string - a known issue with fgets.
input: the buffer to read into, the number of chars to read
*/
void myFgets(char str[], int n)
{
	fgets(str, n, stdin);
	str[strcspn(str, "\n")] = 0;
}