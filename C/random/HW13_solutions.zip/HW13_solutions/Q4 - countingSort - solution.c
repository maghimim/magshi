/*********************************
* Class: MAGSHIMIM C1			 *
* Week 13          				 *
* Homework solution  			 *
**********************************/
#include <stdio.h>

#define COUNTER_SIZE 256
#define ARR_LEN 17

#define FALSE 0
#define TRUE !FALSE

void inputArray(int arr[]);
void countingSort(int arr[]);
void printArray(int arr[]);

int main(void)
{	
	unsigned int arr[ARR_LEN] = {0}; 
	inputArray(arr);
	
	printf("Before:\n");
	printArray(arr);
	
	countingSort(arr);
	
	printf("After:\n");
	printArray(arr);

	return 0;
}

/*
Function will fill array with user's input
input: the array to fill
output: none
*/
void inputArray(int arr[])
{
	printf("Enter %d numbers: \n", ARR_LEN);
	int i = 0;
	for(i = 0; i < ARR_LEN; i++)
	{
		scanf("%d", &arr[i]);
	}
}

/*
This function will sort an array using the counting sort algorithm.
input: array to sort 
output: none
*/
void countingSort(int arr[])
{
	int i = 0, index = 0;
	int done = FALSE;
	unsigned int counter[COUNTER_SIZE] = {0};

	//count how many times each value exists in the input array.
	for(i = 0; i < ARR_LEN; i++)
	{
		counter[arr[i]]++; //the value in "arr" is the index in "counter"
	}
	//sorting the input array according to the "counter" array.
	for(i = 0; i < COUNTER_SIZE && !done; i++)
	{
		while(counter[i])
		{
			arr[index] = i;
			counter[i]--;
			index++;
			
			//arr is full, there is no need to keep looping
			if(i == ARR_LEN - 1)
			{
				done = TRUE;
			}
		}
	}
}


/*
Function will print array
input: array to print
output: none
*/
void printArray(int arr[])
{
	int i = 0;
	for(i = 0; i < ARR_LEN; i++)
	{
		printf("%d ",arr[i]);	
	}	
	printf("\n");
}
