/*********************************
* Class: MAGSHIMIM C1			 *
* Week 13           			 *
**********************************/
#include <stdio.h>

#define MAT_SIZE 4
#define MAGICAL 1

int checkIfMagic(int mat[][MAT_SIZE]);
int sumRow(int mat[][MAT_SIZE], int row);
int sumCol(int mat[][MAT_SIZE], int col);
int sumMainDiagonal(int mat[][MAT_SIZE]);
int sumSecDiagonal(int mat[][MAT_SIZE]);
void printMatrix(int mat[][MAT_SIZE]);
void initMatrix(int mat[][MAT_SIZE]);

int main(void)
{
	/*
	int magic[][MAT_SIZE] = { {16,  3,  2, 13},
							  { 5, 10, 11,  8},
							  { 9,  6,  7, 12},
							  { 4, 15, 14,  1} };
	
	int nonMagic[][MAT_SIZE] = { { 1,  2,  3,  4},
								 { 5,  6,  7,  8},
								 { 9, 10, 11, 12},
								 {13, 14, 15, 16} };
	*/							 
	int mat [MAT_SIZE][MAT_SIZE] = {0};
	initMatrix(mat);
	printf("Is the following matrix a magic square?\n");
	if(checkIfMagic(mat))
	{
		printf("Yes\n");
	}
	else
	{
		printf("No\n");
	}
	printMatrix(mat);
	
	return 0;
}

/**
Returns if a matrix represents a magic square
Input: 	mat - matrix of integer values
Output: positive number if mat is a square matrix, zero otherwise
*/
int checkIfMagic(int mat[MAT_SIZE][MAT_SIZE])
{
	int sum = sumRow(mat,0);
	int isMagic = MAGICAL;
	int i = 0;
	
	// Check if all other rows equal the first row
	for(i = 1; i < MAT_SIZE && isMagic; i++)
	{
		isMagic = (sumRow(mat,i) == sum) ? MAGICAL : !MAGICAL;
	}
	
	// Check if all the cols equal the first row
	for(i = 0; i < MAT_SIZE && isMagic; i++)
	{
		isMagic = (sumCol(mat,i) == sum) ? MAGICAL : !MAGICAL;
	}
	
	// Check if the main and secondary diagonal equal the first row
	isMagic = (isMagic && sumMainDiagonal(mat) == sum) ? MAGICAL : !MAGICAL;
	isMagic = (isMagic && sumSecDiagonal(mat) == sum) ? MAGICAL : !MAGICAL;
	
	return isMagic;
}


/**
Returns the sum of the matrix along specific row
Input: 	mat - matrix of integer values
		row - row for which a sum is calculated
Output: The summation of all elements in matrix along the given row
*/
int sumRow(int mat[MAT_SIZE][MAT_SIZE], int row)
{
	int col = 0;
	int sum = 0;
	for(col = 0; col < MAT_SIZE; col++)
	{
		sum += mat[row][col];
	}
	return sum;
}

/**
Returns the sum of the matrix along specific col
Input: 	mat - matrix of integer values
		col - col for which a sum is calculated
Output: The summation of all elements in mat along the given col
*/
int sumCol(int mat[MAT_SIZE][MAT_SIZE], int col)
{
	int row = 0;
	int sum = 0;
	for(row = 0; row < MAT_SIZE; row++)
	{
		sum += mat[row][col];
	}
	return sum;
}

/**
Returns the sum of the matrix along main diagonal
Input: 	mat - matrix of integer values
Output: The summation of all elements in mat along the main diagonal
*/
int sumMainDiagonal(int mat[MAT_SIZE][MAT_SIZE])
{
	int ind = 0;
	int sum = 0;
	for(ind = 0; ind < MAT_SIZE; ind++)
	{
		sum += mat[ind][ind];
	}
	return sum;
}

/**
Returns the sum of the matrix along secondary diagonal
Input: 	mat - matrix of integer values
Output: The summation of all elements in mat along the secondary diagonal
*/
int sumSecDiagonal(int mat[MAT_SIZE][MAT_SIZE])
{
	int ind = 0;
	int sum = 0;
	for(ind = 0; ind < MAT_SIZE; ind++)
	{
		sum += mat[ind][(MAT_SIZE - 1) - ind];
	}
	return sum;
}

/**
Prints a matrix row by row.
Input: 	mat - The matrix to print
Output: None
*/
void printMatrix(int mat[][MAT_SIZE])
{
	int row = 0;
	int col = 0;
	for( row = 0 ; row < MAT_SIZE ; row++ )
	{
		for( col = 0 ; col < MAT_SIZE ; col++ )
		{
			printf("%4d",mat[row][col]);
		}
		printf("\n");
	}
}

/**
Init a matrix row by row.
Input: 	mat - The matrix to init
Output: None
*/
void initMatrix(int mat[][MAT_SIZE])
{
	int row = 0;
	int col = 0;
	for( row = 0 ; row < MAT_SIZE ; row++ )
	{
		for( col = 0 ; col < MAT_SIZE ; col++ )
		{
			printf("Please enter value for the [%d][%d] cell \n",row,col);
			scanf("%d",&mat[row][col]);
		}
		printf("\n");
	}
}
