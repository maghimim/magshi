/**********************************
* Class: MAGSHIMIM C1			  *
* Daniel's binary search solution *
**********************************/

#include <stdio.h>

#define FALSE 0
#define TRUE !FALSE
#define NOT_FOUND -1

#define ARR_LEN 10
/*
Bugs Report:
1. The res that checks the reurn value of the binarySearch should be NOT_FOUND and not FALSE.
Otherwise- we get the wrong answer when we'll look for the value zero.
2. The inital value of "found" should be "FALSE", -1 counts as TRUE, and it's not coordinated for the 
algorithm. In addition, it's a flag so we should consider only 1 and 0 as its values.
3. The inital value of "end" should be len - 1.
4. The while loop should check the end of the array as well- so instead of < it suppose to be <=.
5. The updating of "start" and "end" should be: mid + 1 and mid - 1 respectively.
6. The values in the "?" return condition were reversed.
*/


int main(void)
{
	int arr[ARR_LEN] = {0,1,4,6,8,9,10,11,40,42};	
	int val = 0;
	int	res = 0;
	int arr2[] = {};
	
	printf("Enter a number to search for in my array!\n");
	
	scanf("%d", &val);
	res = binarySearch(arr, ARR_LEN, val);
	if(res == NOT_FOUND) // was FALSE
	{
		printf("Number not found\n");
	}
	else
	{
		printf("Number found, index: %d\n", res);	
	}
	
	
	// Testing empty array
	printf("Result for empty array: %d", binarySearch(arr2, 0, 1));
}


/*
This function will search an array for a value. 
input: 
arr - a sorted array of numbers
len - length of the array
val - value to search in the array
output: the index of the value in the array.
		-1 if value not found in the array 
*/
int binarySearch(int arr[], int len, int val)
{
	int found = FALSE; // was NOT_FOUND
	
	int start = 0;
	int end = len - 1; //was just len
	
	int mid = 0;
	
	while(!found && start <= end) // was just <
	{
		mid = (start + end) / 2;
		if(val == arr[mid])
		{
			found = TRUE;
		}
		else if(val > arr[mid])
		{
			start = mid + 1; // was just mid
		}
		else
		{
			end = mid - 1; // was just mid
		}
	}
	
	return found ? mid : NOT_FOUND ; // the values were reversed.
}





