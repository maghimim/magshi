/*********************************
* Class: MAGSHIMIM C1			 *
* Week 13          				 *
* Homework solution  			 *
**********************************/

#include <stdio.h>
#include <string.h>

#define STR_LEN 50

int myStrcmp(const char str1[], const char str2[]);
int myStrlen(const char str[]);
void myStrncat(char dest[], const char src[], unsigned int n);

void myFgets(char str[], int n);

int main(void)
{
	char str1[STR_LEN] = {0};
	char str2[STR_LEN] = {0};
	int res = 0;
	
	printf("Enter first string: ");
	myFgets(str1, STR_LEN);
	printf("Enter second string: ");
	myFgets(str2, STR_LEN);
	
	printf("First string length: %d\n", myStrlen(str1));
	printf("Second string length: %d\n", myStrlen(str2));
	
	myStrncat(str1, str2, STR_LEN);
	puts(str1);

	return 0;
}

/* function performs the strlen function
parameters: string to check.
return: the length of the string.
*/
int myStrlen(const char str[])
{
	int i=0;
	
	while(str[i] != 0)
	{
		i++;
	}
	
	return i;
}

/*
strncat implemention from http://clc-wiki.net/wiki/C_standard_library:string.h:strncat
input: destination and source strings, and number of chars to concatenate.
*/

// Note: strncat returns a pointer (address) of destination string. 
// Since we do not know pointers yet, it is OK to have it return void
// char * myStrncat(char dest[], const char src[], unsigned int n)
void myStrncat(char dest[], const char src[], unsigned int n)
{
    int i = 0;
	int destLen = 0;
	
    // get length of dest string
	while (dest[destLen])
	{
        destLen++;
	}
	
    for (i = 0; i < n; i++)
	{
		dest[destLen + i] = src[i];
	}
	dest[destLen + i] = 0;
	
    // return dest;
}

/*
Function will perform the fgets command and also remove the newline 
that might be at the end of the string - a known issue with fgets.
input: the buffer to read into, the number of chars to read
*/
void myFgets(char str[], int n)
{
	fgets(str, n, stdin);
	str[strcspn(str, "\n")] = 0;
}