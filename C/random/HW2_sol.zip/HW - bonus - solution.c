/*********************************
* Class: MAGSHIMIM C1			 *
* Week 2           				 *
* HW solution (Bonus)		 *
* Tricky switch					 *
**********************************/


#include <stdlib.h>
#include <stdio.h>

/**
The program exchange the values of two numbers without using a temporary variable.

Input:
	None
Output:
	The program returns 0 upon successful completion of its running
*/
int main(void)
{
	int a = 53, b = 12;

	printf("a: %d, b: %d\n", a, b);
	a += b;
	b = a - b;
	a -= b;

	printf("a: %d, b: %d\n", a, b);
	
	//another way:
	
	a *= b;
	b = a / b;
	a /= b;
	printf("a: %d, b: %d\n", a, b);
	return 0;
} 