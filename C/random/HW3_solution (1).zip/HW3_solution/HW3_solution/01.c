/*********************************
* Class: MAGSHIMIM C2			 *
* Week 1               			 *
**********************************/

#include <stdio.h>

int main(void)
{
	printf("Testing...");
	
	getchar();	
	return 0;
}