/*********************************
* Class: MAGSHIMIM C2			 *
* Week 3           				 *
* HW solution   			 	 *
**********************************/

#include <stdio.h>

#define SIZE 3
void pointerToX(int* arr, int n, int x);

int main(void)
{
	int arr[] = {0};
	int x = 0 , i = 0;
	for (i = 0; i < SIZE; i++)
	{
		printf("Please enter a number for index %d: ", i);
		scanf("%d", arr + i);
	}
	printf("Please enter a number to search in the array: ");
	scanf("%d", &x);
	
	pointerToX(arr, SIZE, x);
	printf("after foo");
//	getchar();
	return 0;
}

/*
The function checks if an element (cell in memory) is contained
in an array or not. If it does, it prints all the value proceeding it.
Otherwise, it informs the user about it.

Input:
	arr - array of integers
	n - array length
	x - an element in memory
*/
void pointerToX(int* arr, int n, int x)
{
	int i = 0, found = 0;
	for (i; i < n && !found; i++)
	{
		if (*(arr + i) == x)
		{
			found = 1;
			printf("The value's address is: %p", arr + i);
		}
	}
	if(!found)
	{
		printf("Not in the array.\n");
	}
}
