/*********************************
* Class: MAGSHIMIM C2			 *
* Week 3           				 *
* HW solution   			 	 *
**********************************/
#include <stdio.h>
#include <string.h>


void printArray(char* p, int len)
{
	// infinite loop here! because p changes all the time...
	// it's like writing x < x+1, it is always TRUE!
	// for( p ; p < p + len ; p++ ) 
	// fixed:
	char * a = 0;
	for(a = p; a < p + len; a++)
	{
		printf("%c", *a);
	}
	printf("\n");
}

int main(void)
{
	char* msg = "hi jyegq meet me at 2 :)"; // using the decrypting from q4 (with key=2) - it's sigal!
	printArray(msg, strlen(msg));
	getchar();
	return 0;
 }
