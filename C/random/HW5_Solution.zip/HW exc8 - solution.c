/*********************************
* Class: MAGSHIMIM C1			 *
* Week 5           				 *
* Class solution 6  			 *
* Prime numbers					 *
**********************************/

#include <stdlib.h>
#include <stdio.h>

/**
The program prints all the prime numbers in the range 1-1000

Input:
	None
Output:
	The program returns 0 upon successful completion of its running (windows convention)
*/
int main(void)
{
	// Variable declaration
	const unsigned int FALSE = 0;
	const unsigned int TRUE = !FALSE;
	const unsigned int UPPER_LIMIT = 1000;
	unsigned int num=0;
	unsigned int divider=0;
	unsigned int isPrime=0;
	int counter = 0;
	
	// Go over all numbers in the range 1-1000
	for (num = 2; num <= UPPER_LIMIT; num++)
	{
		// At the beginning every number is considered a prime number
		isPrime = TRUE;
		// Go over all numbers smaller than half the number of the outside loop.
		// For every smaller number check if it divides num. If it does, num is not a prime.
		// We need to start with 2 since every number divides by 1.
		// We can end at (num / 2) since a number can't be divided by a number
		// bigger than it's half without a remainder (we can actually stop at square(num))
		for (divider = 2; divider <= num / 2 && isPrime; divider++)
		{
			if (num % divider == 0)
			{
				// Since 'divider' divides 'num' without a remainder, num is not a prime
				isPrime = FALSE;
			}
		}
		
		if (isPrime)
		{
			// No dividers were found
			printf("Prime number: %d\n", num);
			counter++;
		}
	}

	printf("Num of primes: %d\n", counter);
	return 0;
}
