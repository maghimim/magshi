/*********************************
* Class: MAGSHIMIM C1			 *
* Week 5           				 *
* Calculate factorial			 *
*********************************/

#include <stdlib.h>
#include <stdio.h>

/**
The program calculate factorials of integer numbers.
It works as follows:
1. Get user input.
2. Check whether the input is valid or not (valid if and only if the number is positive).
3. Calculate the factorial.

Input:
	None
Output:
	The program returns 0 upon successful completion of its running (windows convention)
*/
int main(void)
{
	// Variable declaration
	int num =0;				
	unsigned int isValid =1;			// Flag, indicating if the input is valid
	unsigned int fact = 1;			// Value used for intermidate calculations
	int i =0;					// loop variable
	char ans = 0;
	
	do
	{
		// get input until it is valid
		do
		{
			printf("Enter number: ");		// Get the user input
			scanf("%d", &num);
			getchar(); // clean buffer

			isValid = (num > 0);				// Assign the condition result into a variable

			if (!isValid)					// If input is not valid, inform the user
			{
				printf("Invalid input!\n");
			}
		}
		while (!isValid);
		
		fact = 1;
		// Calculate factorial value
		// num! = 1 * 2 * 3 * ... * (num-1) * num
		for (i = 1; i <= num; ++i)
		{
			fact *= i;
		}

		printf("Factorial of %d is %d\n", num, fact);
		printf("Would you like to try again?\nClick 'y' for yes or other key for no\n");
		ans = getchar();
	}
	while(ans == 'y');
	return 0;

}