/*********************************
* Class: MAGSHIMIM C1			 *
* Week 5           				 *
* Loop Conventions				 *
*********************************/

#include <stdio.h>

/*
Daniel's mistakes: 
- no brackets {  } for the second (inner) loop
- used Magic Numbers instead of constants
- loop variables should usually be called i,j etc.
- excessive (too much) documentation.
- the first element of the first loop was missing.
- the promotion of the loop variable in the inner loop was wrong.
- are there other mistakes?
*/

// Constants - Number of columns and rows
#define ROWS 10 
#define COLS 10

int main(void)
{
	int i = 0; 
	int j = 0;
	
	printf("Daniel Presents: The Board of Multiplication!\n\n");
	
	// Loop to print board
	for(i = 1; i < ROWS; i++)
	{
		for(j = 1; j < COLS; j++)
		{
			printf("%4d", i * j); // Printing multiplication
		}
		printf("\n"); 
	}
		
	return 0;
}