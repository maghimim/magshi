/*********************************
* Class: MAGSHIMIM C1			 *
* Week 5           				 *
* Invert a number				 *
*********************************/

#include <stdlib.h>
#include <stdio.h>

/**
The program inverts the order of numbers

Input:
	None
Output:
	The program returns 0 upon successful completion of its running (windows convention)
*/
int main(void)
{
	int num=0;						// Not initialized since it is determined by user input
	unsigned int isValid=1;					// Flag, indicating if the input is valid
	unsigned int revNum = 0;					// Used to save the inverted number
	unsigned int digitsNumber = 1;
	unsigned int currDigit=0;

	// get input until it is valid
	do
	{
		printf("Enter number: ");		// Get the user input
		scanf("%d", &num);

		isValid = num > 0;				// Assign the condition result into a variable

		if (!isValid)					// If input is not valid, inform the user
		{
			printf("Invalid input! Positive numbers only.\n");
		}
	}
	while (!isValid);
	
	printf("Original number: %d\n", num);

	// Reverse the number
	while (num > 0)
	{
		currDigit = num % 10; 			// Get current last digit
		revNum *= 10;					// Multiply reversed number by 10 (resulting in the same number with 0 on the right), all previous digits are pushed to the left
		revNum += currDigit;			// Add the last digit
		num /= 10;						// Divide by 10 (discard the right digit of the input number)
	}
	
	printf("After reverse: %d\n", revNum);
	
	return 0;
}