/*********************************
* Class: MAGSHIMIM C1			 *
* Week 5           				 *
* 4 is magic					 *
*********************************/


#include<stdio.h>
#include<conio.h>

/**
This riddle is originally called "four is magic".

The solution for the riddle: In every transition we replace the number
with its length when written in English.

For example (on the input 7):
Since seven is written with five letters we have
7 goes to 5
Since five is written with four letters we have
5 goes to 4
Since four is written with four letters we have
4 goes to 4 (endless loop!!!)

As any such chain ends with 4 (try it!!!) we always end the loop with
"four is MAGSHIMIM".

The following code is its implementation for the range 0-20.

Input:
	None
Output:
	The program returns 0 upon successful completion of its running (windows convention)
*/
int main(void)
{		   
	// Variable declaration
	const unsigned int MAX_VAL = 20;
	const unsigned int MIN_VAL = 0;
	char cnt =0 ;					// Continue flag
	int num =0;					// User input
	int $abc = 0;
	$abc = 6;
	printf("%d", $abc);
	
	// Loop as long the user wants to continue
	do
	{
		// Loop until a valid input is inserted
		do
		{
			printf("Please enter a number between %d and %d: ",MIN_VAL,MAX_VAL);
			scanf("%d", &num);
		} while(!(num >= MIN_VAL && num <= MAX_VAL));
		
		// Loop until you reach 4
		while(num != 4)
		{
			// if-else condition, according to the length of the numbers
			if(num == 0 || num == 5 || num == 9)
			{
				printf("%d goes to 4\n", num);
				num = 4;
			}
			else if(num == 1 || num == 2 || num == 6 || num == 10)
			{
				printf("%d goes to 3\n", num);
				num = 3;
			}
			else if(num == 3 || num == 7 || num == 8)
			{
				printf("%d goes to 5\n", num);
				num = 5;
			}
			else if(num == 11 || num == 12 || num == 20)
			{
				printf("%d goes to 6\n", num);
				num = 6;
			}
			else if(num == 15 || num == 16)
			{
				printf("%d goes to 7\n", num);
				num = 7;
			}
			else if(num == 13 || num == 14 || num == 18 || num == 19)
			{
				printf("%d goes to 8\n", num);
				num = 8;
			}
			else
			{
				printf("%d goes to 9\n", num);
				num = 9;
			}
		}
		// Last line is always 4 is magic!
		printf("4 goes to MAGSHIMIM!\n\n");
		
		printf("Do you want to continue (y/n)?\n\n");
		cnt = getch();
	} while(cnt == 'y' || cnt == 'Y');
	
	return 0;
}

