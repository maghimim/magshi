/*********************************
* Class: MAGSHIMIM C1			 *
* Week 10           				 *
* Help my array solution		 *
**********************************/

#include <stdio.h>
#include <stdlib.h>

#define ARR_LENGTH 2

void initArray(int arr[]); // function can't (and doesn't need to) return array!
void printGrades(int first, int second);

int main(void)
{
	int myGrades[] = {0,0};
	
	initArray(myGrades); // we can just send the array to the function and it will change
	
	int first = myGrades[0]; /* without the [0] we are putting the ADDRESS of the array into first.
							 since an address is a number, this can be done "legally"
							 and the number printed to the screen will be the address
							 of the beginning of the array myGrades
						  */
	int second = myGrades[1];	
	
	printGrades(first, second);
	return 0;
}

/*
Function will change values of array (input from user)
input: array to change
output: fixed array
*/
void initArray(int arr[]) // change to void and no return statement
{
	printf("Enter grades in English and history: ");
	scanf("%d %d", &arr[0], &arr[1]);
}

/*
Function will print two grades
input: the grades to print
output: none
*/
void printGrades(int first, int second)
{
	printf("My grade in English is: %d!\n",first);
	printf("My grade in History is %d! Great Success!\n",second);
}
