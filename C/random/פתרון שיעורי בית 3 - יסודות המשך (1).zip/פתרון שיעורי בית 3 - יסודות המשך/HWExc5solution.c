/*********************************
* Class: MAGSHIMIM C1			 *
* Week 2           				 *
* HW solution 10	  			 *
* ASCII Table					 *
**********************************/


#include <stdlib.h>
#include <stdio.h>

/**
The program counts the number of English letters using the ASCII table

Input:
	None
Output:
	The program returns 0 upon successful completion of its running
*/
int main(void)
{
	char c1 = 'A';
	char c2 = 'Z';
	
	printf("The first letter is %c\n", c1);
	printf("The second letter is %c\n", c2);
	printf("The number of English letters is %d\n", c2 - c1 + 1); // we add 1 to count the difference
	
	return 0;
} 