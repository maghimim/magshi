/*********************************
* Class: MAGSHIMIM C1			 *
* Week 2           				 *
* HW solution 1  			 	 *
* Temperature Converter			 *
**********************************/

#include <stdlib.h>
#include <stdio.h>

#define FAHTENHEIT_MUL 9.0/5.0
#define FAHTENHEIT_ADD 32

/**
The program get a temperature in Celsius from the user, converts it to Fahrenheit
and prints the result to the command line.

Input:
	None
Output:
	The program returns 0 upon successful completion of its running
*/
int main(void)
{
	//Constant
	int celsius = 0;
	float fahrenheit = 0;

	printf("Enter celsius degree: ");
	scanf("%d", &celsius);

	fahrenheit = (float)celsius * FAHTENHEIT_MUL + FAHTENHEIT_ADD;
	printf("Fahrenheit = %.2f\n", fahrenheit);

	return 0;
} 