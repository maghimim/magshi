/*********************************
* Class: MAGSHIMIM C1			 *
* Week 2           				 *
* HW solution 2  			 	 *
* BMI Calculator				 *
**********************************/

#include <stdlib.h>
#include <stdio.h>

/**
Compute the BMI of the user
*/
int main(void)
{

	float heightMeters = 0;
	float weightKg = 0;
	float BMI = 0;

	// Get data from user
	printf("Insert your height in meters and weight in kilograms (with space between): ");
	scanf("%f %f", &heightMeters, &weightKg);
	
	// calculate the BMI
	BMI = weightKg / (heightMeters * heightMeters);

	printf("Height = %.2f, Weight = %.2f, BMI = %.2f\n", heightMeters, weightKg, BMI);

	return 0;
} 