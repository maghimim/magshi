/*********************************
* Class: MAGSHIMIM C1			 *
* Week 2           				 *
* HW solution 1  			 	 *
* Temperature Converter			 *
**********************************/

#include <stdlib.h>
#include <stdio.h>

#deinfe KELVIN_ADD = 273.16;

/**
The program get a temperature in Celsius from the user, converts it to Kelvin
and prints the result to the command line.

Input:
	None
Output:
	The program returns 0 upon successful completion of its running
*/
int main(void)
{
	//Constant
	int celsius = 0;
	float kelvin = 0;

	printf("Enter celsius degree: ");
	scanf("%d", &celsius);

	kelvin = (float)celsius + KELVIN;
	printf("Kelvin = %.2f\n", kelvin);

	system("PAUSE");
	return 0;
} 