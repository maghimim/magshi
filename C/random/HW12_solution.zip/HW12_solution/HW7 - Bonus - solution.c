/*********************************
* Class: MAGSHIMIM C1			 *
* Week 12           			 *
* HW solution 		  			 *
**********************************/

#include <stdio.h>

#define ROWS 		5
#define COLS		5
#define FILL_SMILE	'*'
#define FILL_EYES	'#'
#define EMPTY		' '

void paintBoard(int grid[][COLS]);
void printBoard(int grid[][COLS]);

int main(void)
{
	int grid[ROWS][COLS] = {0}; 
	
	paintBoard(grid);
	printBoard(grid);

	return 0;
}

/*
The function will fill some cells according to the chosen picture.
input: an empty grid
output: the same grid with "filled" cells.
*/
void paintBoard(int grid[][COLS])
{
	grid[1][1] = FILL_EYES;
	grid[1][3] = FILL_EYES;
	grid[3][0] = FILL_SMILE;
	grid[3][4] = FILL_SMILE;
	grid[4][1] = FILL_SMILE;
	grid[4][2] = FILL_SMILE;
	grid[4][3] = FILL_SMILE;
}

/*
Function will print the grid
input: the grid  
output: none
*/
void printBoard(int grid[][COLS])
{
	int i = 0, j = 0;	
	for (i = 0; i < ROWS; i++)
	{
		for (j = 0; j < COLS; j++)
		{
			printf("%c ",grid[i][j]);
		}
		printf("\n");
	}
}
