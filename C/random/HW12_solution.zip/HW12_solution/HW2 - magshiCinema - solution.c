/*********************************
* Class: MAGSHIMIM C1			 *
* Week 12           			 *
* HW Solution - MagshiCinema	 *
**********************************/

#include <stdio.h>

#define PRINT_CINEMA_OPTION 1
#define BUY_SEAT_OPTION 2
#define TAKEN_SEATS_OPTION 3
#define DISCOUNT_SEAT_OPTION 4
#define NEW_FIXED_PRICE_OPTION 5
#define EXIT_OPTION 6

#define ROWS 5
#define SEATS_IN_ROW 3

#define CHEAP_TICKET_PRICE 25
#define NORMAL_TICKET_PRICE 35
#define VIP_TICKET_PRICE 50
#define DISCOUNTED_RATE .9

#define SEAT_TAKEN -1
#define PURCHASE_SUCCESSFUL 1
#define PURCHASE_FAIL 0

void printCinema(int cinema[][SEATS_IN_ROW]);
int buySeat(int cinema[][SEATS_IN_ROW], int row, int seat);
int calcTakenSeats(int cinema[][SEATS_IN_ROW]);
void discountSeat(int cinema[][SEATS_IN_ROW], int row, int seat);
void setNewFixedPrice(int cinema[][SEATS_IN_ROW], int price); 

int main(void)
{
	int cinema[ROWS][SEATS_IN_ROW] = {{CHEAP_TICKET_PRICE, CHEAP_TICKET_PRICE, CHEAP_TICKET_PRICE},
									  {NORMAL_TICKET_PRICE, NORMAL_TICKET_PRICE, NORMAL_TICKET_PRICE},
									  {NORMAL_TICKET_PRICE, VIP_TICKET_PRICE, NORMAL_TICKET_PRICE},
									  {NORMAL_TICKET_PRICE, NORMAL_TICKET_PRICE, NORMAL_TICKET_PRICE},
									  {CHEAP_TICKET_PRICE, CHEAP_TICKET_PRICE, CHEAP_TICKET_PRICE}};
	int choice = 0;
	int row = 0, seat = 0;
	int result = 0;
	int price = 0;
	
	do 
	{
		printf("\nWelcome to MagshiCinema\n");
		printf("Select an option:\n");
		printf("%d - Print cinema hall\n", PRINT_CINEMA_OPTION);
		printf("%d - Buy a ticket\n", BUY_SEAT_OPTION);
		printf("%d - Print number of taken seats\n", TAKEN_SEATS_OPTION);
		printf("%d - Make a seat discount\n", DISCOUNT_SEAT_OPTION);
		printf("%d - Set a new price for all seats\n", NEW_FIXED_PRICE_OPTION);
		printf("%d - Exit\n", EXIT_OPTION);
		scanf("%d",&choice);
  
		switch (choice)
		{
			case PRINT_CINEMA_OPTION: 
				printCinema(cinema);
				break;
			case BUY_SEAT_OPTION: 
				printf("Which row (0-%d)? ", ROWS-1);
				scanf("%d", &row);
				printf("Which seat (0-%d)? ", SEATS_IN_ROW-1);
				scanf("%d", &seat);
				if(buySeat(cinema, row, seat))
				{
					printf("You got the seat!\n");
				}
				else
				{
					printf("Seat taken!\n");
				}
				break;
			case TAKEN_SEATS_OPTION:
				printf("%d taken seats in the cinema\n", calcTakenSeats(cinema));
				break;
			case DISCOUNT_SEAT_OPTION:
				printf("Which row (0-%d)? ", ROWS-1);
				scanf("%d", &row);
				printf("Which seat (0-%d)? ", SEATS_IN_ROW-1);
				scanf("%d", &seat);
				discountSeat(cinema, row, seat);
				break;
			case NEW_FIXED_PRICE_OPTION:
				printf("Enter new price: ");
				scanf("%d", &price);
				setNewFixedPrice(cinema, price); 
				break;
			case EXIT_OPTION: 
				printf("Thank you come again.\n"); 
				break;
			default: 
				printf("Wrong Choice. Enter again\n");
                break;
			printf("\n");
		} 
 	} while (choice != EXIT_OPTION);

	return 0;
}

/*
Print a cinema hall ticket prices
Input: 	hall to print
Output: None
*/
void printCinema(int mat[][SEATS_IN_ROW])
{
	int row = 0;
	int col = 0;
	for(row = 0; row < ROWS; row++)
	{
		for(col = 0; col < SEATS_IN_ROW; col++)
		{
			printf("%d ",mat[row][col]);
		}
		printf("\n");
	}
}

/*
Function lets user buy a seat in the cinema hall
input: hall and row+seat of ticket to buy
output: none
*/
int buySeat(int cinema[][SEATS_IN_ROW], int row, int seat)
{
	int result = 0;
	if(cinema[row][seat] == SEAT_TAKEN)
	{
		result = PURCHASE_FAIL;
	}
	else
	{
		cinema[row][seat] = SEAT_TAKEN;
		result = PURCHASE_SUCCESSFUL;
	}
	return result;
}

/*
Calc number of taken seats in a cinema
Input: the cinema hall
Output: number of taken seats
*/
int calcTakenSeats(int cinema[][SEATS_IN_ROW])
{
	int row = 0;
	int col = 0;
	int counter = 0;
	for(row = 0; row < ROWS; row++)
	{
		for(col = 0; col < SEATS_IN_ROW; col++)
		{
			if(cinema[row][col] == SEAT_TAKEN)
			{
				counter++;
			}
		}
	}
	return counter;
}

/*
Function makes a discount for a seat in the cinema hall
input: hall and row+seat of ticket to discount
output: none
*/
void discountSeat(int cinema[][SEATS_IN_ROW], int row, int seat)
{
	if(cinema[row][seat] != SEAT_TAKEN)
	{
		cinema[row][seat] = DISCOUNTED_RATE * (cinema[row][seat]);	
	}
}

/*
Function sets a new price for all seats in the cinema hall
input: hall and new price
output: none
*/
void setNewFixedPrice(int cinema[][SEATS_IN_ROW], int price)
{
	int row = 0;
	int col = 0;
	for(row = 0 ;row < ROWS; row++)
	{
		for(col = 0 ;col < SEATS_IN_ROW ;col++ )
		{
			if(cinema[row][col] != SEAT_TAKEN)
			{
				cinema[row][col] = price;
			}			
		}
	}
}