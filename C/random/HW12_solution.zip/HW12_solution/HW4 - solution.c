/*********************************
* Class: MAGSHIMIM C1			 *
* Week 12           			 *
* Names							 *
**********************************/

#include <stdio.h>
#include <string.h>

#define NUM_NAMES 10
#define NAME_LEN 50

void myFgets(char str[], int n);
void printShortestName(char names[][NAME_LEN]);
void printLongestName(char names[][NAME_LEN]);
void printFirstOrderName(char names[][NAME_LEN]);
void printLastOrderName(char names[][NAME_LEN]);

int main(void)
{
	char names[NUM_NAMES][NAME_LEN] = {0};

	int i = 0;
	
	printf("Enter %d names:\n", NUM_NAMES);
	for(i = 0; i < NUM_NAMES; i++)
	{
		myFgets(names[i], NAME_LEN);
		
	}
	printf("\n");
	
	printShortestName(names);
	printLongestName(names);
	printFirstOrderName(names);
	printLastOrderName(names);
	
	return 0;
}

/*
Function prints the shortest name
input: list of names
output: none
*/
void printShortestName(char names[][NAME_LEN])
{
	int minLen = NAME_LEN+1;
	int minLenIndex = -1;
	int i = 0;
	
	for(i = 0; i < NUM_NAMES; i++)
	{
		if(strlen(names[i]) < minLen)
		{
			minLen = strlen(names[i]);
			minLenIndex = i;
		}		
	}
	printf("Shortest: %s\n", names[minLenIndex]);
}

/*
Function prints the longest name
input: list of names
output: none
*/
void printLongestName(char names[][NAME_LEN])
{
	int maxLen = 0;
	int maxLenIndex = -1;
	int i = 0;
	
	for(i = 0; i < NUM_NAMES; i++)
	{
		if(strlen(names[i]) > maxLen)
		{
			maxLen = strlen(names[i]);
			maxLenIndex = i;
		}		
	}
	printf("Longest: %s\n", names[maxLenIndex]);
}

/*
Function prints the first name (alphabetically)
input: list of names
output: none
*/
void printFirstOrderName(char names[][NAME_LEN])
{
	int firstIndex = 0;
	int i = 0;
	
	for(i = 1; i < NUM_NAMES; i++)
	{
		if(strcmp(names[firstIndex],names[i]) > 0)
		{
			firstIndex = i;
		}		
	}
	printf("First: %s\n", names[firstIndex]);
}

/*
Function prints the last name (alphabetically)
input: list of names
output: none
*/
void printLastOrderName(char names[][NAME_LEN])
{
	int lastIndex = 0;
	int i = 0;
	
	for(i = 1; i < NUM_NAMES; i++)
	{
		if(strcmp(names[lastIndex],names[i]) < 0)
		{
			lastIndex = i;
		}		
	}
	printf("Last: %s\n", names[lastIndex]);
}

/*
Function will perform the fgets command and also remove the newline 
that might be at the end of the string - a known issue with fgets.
input: the buffer to read into, the number of chars to read
*/
void myFgets(char str[], int n)
{
	fgets(str, n, stdin);
	str[strcspn(str, "\n")] = 0;
}