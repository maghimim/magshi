/*********************************
* Class: MAGSHIMIM C1			 *
* Week 12           			 *
* HW solution 		  			 *
**********************************/

#include <stdio.h>

#define COURSES 	3
#define EXERCISES	11

void printGradesheet(int grades[][EXERCISES]);

int main(void)
{
	int myGrades[COURSES][EXERCISES] = {80,60,70}; // no good
	/*
	resulting sheet will be
	80|60|70|0|0|0|0|0|0|0|0
	 0| 0| 0|0|0|0|0|0|0|0|0
	 0| 0| 0|0|0|0|0|0|0|0|0
	 
	 why? 
	 because the compiler sees the size of the full matrix (3*11) and since only three values are given, 
	 it initializes the rest with 0 (the default value).
	 So actually the command is:
	 int myGrades[COURSES][EXERCISES] = {80,60,70,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0...} so on 33 values.
	 which is the same as writing
	 int myGrades[COURSES][EXERCISES] = {{80,60,70,0,0,0,0,0,0,0,0},
										 {0,0,0,0,0,0,0,0,0,0,0}, 
										 {0,0,0,0,0,0,0,0,0,0,0}};
	*/
	
	// should be: 
	int fixedGrades[COURSES][EXERCISES] = {{80}, {60}, {70}};
	
	/*
	less elegant option:
	int fixed2[COURSES][EXERCISES] = {0};
	fixed2[0][0] = 80;
	fixed2[1][0] = 60;
	fixed2[2][0] = 70;
	*/
	
	/* 
	even less elegant solution: 
	int fixed3[COURSES][EXERCISES] = {{80,0,0,0,0,0,0,0,0,0,0},
										   {60,0,0,0,0,0,0,0,0,0,0}, 
										   {70,0,0,0,0,0,0,0,0,0,0}}
	*/
	
	printf("Daniel's mistake:\n");
	printGradesheet(myGrades);
	printf("Fixed:\n");
	printGradesheet(fixedGrades);

	return 0;
}

/*
Function will print gradesheet
input: grades to print
output: none
*/
void printGradesheet(int grades[][EXERCISES])
{
	int i = 0, j = 0;	
	//Print the Matrix
	for (i = 0; i < COURSES; i++)
	{
		for (j = 0; j < EXERCISES; j++)
		{
			printf("%d ",grades[i][j]);
		}
		printf("\n");
	}
}