/*********************************
* Class: MAGSHIMIM C1			 *
* Week 12           			 *
* HW solution 		  			 *
**********************************/

#include <stdio.h>

#define ROWS 	10
#define COLS	10

void calcBoard(int grades[][COLS]);
void printBoard(int grades[][COLS]);

int main(void)
{
	int mulTable[ROWS][ROWS] = {0}; 
	
	calcBoard(mulTable);
	printBoard(mulTable);

	return 0;
}

/*
Function will calculaute the multiplication table 
input: an empty board
output: none
*/
void calcBoard(int mulTable[][COLS])
{
	int i = 0, j = 0;	
	for (i = 0; i < ROWS; i++)
	{
		for (j = 0; j < COLS; j++)
		{
			mulTable[i][j] = (i + 1)*(j + 1);
		}
	}
}

/*
Function will print the multiplication table 
input: the multiplication table 
output: none
*/
void printBoard(int mulTable[][COLS])
{
	int i = 0, j = 0;	
	for (i = 0; i < ROWS; i++)
	{
		for (j = 0; j < COLS; j++)
		{
			printf("%3d ",mulTable[i][j]);
		}
		printf("\n");
	}
}
