/*********************************
* Class: MAGSHIMIM C1			 *
* Week 12          				 *
* Homework solution  			 *
**********************************/


#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define STR_LEN 50
#define NUM_WORDS 10
#define NUM_LETTERS 26
#define RANGE 'a'

#define NOT_USED 0
#define USED !NOT_USED

#define FALSE 0
#define TRUE !FALSE

void updateUsed(char word[], char usedArray[]);
int checkPangram(char usedArray[]);
void myFgets(char str[], int n);

int main(void)
{
	char words[NUM_WORDS][STR_LEN] = { 0 };
	char usedLetters[NUM_LETTERS] = { NOT_USED };
	int isPangram = FALSE;
	int i = 0;

	printf("Enter up to 10 words, try to make a pangram:\n");
	for (i = 0; i < NUM_WORDS && !isPangram; i++)
	{
		myFgets(words[i], STR_LEN);
		updateUsed(words[i], usedLetters);
		isPangram = checkPangram(usedLetters);
	}
	printf("It's a pangram?\n");
	isPangram ? printf("Yes!\n") : printf("No\n");

	//getchar();
	return 0;
}

/* The function accepts a string and updates the array (also a parameter) to reflect which letters were used
in this string.
Input: the string and the array of used letters
Output: none
*/
void updateUsed(char word[], char usedArray[])
{
	int i = 0;
	for (i = 0; word[i]; i++)
	{
		usedArray[word[i] - RANGE] = USED;
	}
}

/*
Function checks if all letters are marked as used in the array.
If so, a pangram was achieved
input: array of letters - used or not used
output: true if all letters are used. false otherwise.
*/
int checkPangram(char usedArray[])
{
	int i = 0;
	int isPangram = TRUE;
	for (i = 0; i < NUM_LETTERS && isPangram; i++)
	{
		isPangram = isPangram && (usedArray[i] == USED);
	}
	return isPangram;
}

/*
Function will perform the fgets command and also remove the newline
that might be at the end of the string - a known issue with fgets.
input: the buffer to read into, the number of chars to read
*/
void myFgets(char str[], int n)
{
	fgets(str, n, stdin);
	str[strcspn(str, "\n")] = 0;
}