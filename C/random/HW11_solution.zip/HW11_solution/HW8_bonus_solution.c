/*********************************
* Class: MAGSHIMIM C1			 *
* Week 11          				 *
* Homework solution  			 *
* This solution is based on the	 *
* solution or Orel Adrei from    *
* Magshimim Akko. Thanks Orel!	 *
**********************************/

#include <stdio.h>
#include <math.h>
#include <string.h>

#define STRING_LEN 100

#define POSITIVE_SIGN 1
#define NEGATIVE_SIGN -1

#define DELIMITER_X  'x'
#define MINUS_CHAR '-'
#define DELIMITER_EQUAL '='

#define A_SIGN_INDEX 0
#define A_INDEX 0
#define B_SIGN_INDEX 4
#define B_INDEX 5
#define C_SIGN_INDEX 7
#define C_INDEX 8

void solveEquation(float a, float b, float c);
float getDelta(float a, float b, float c);
void myFgets(char str[], int n);
int getVariable(char equation[], int eqIndex, char var[], char delim);


int main(void)
{
	char quadratic[STRING_LEN] = {0};
	char aStr[100] = {0};
	char bStr[100] = {0};
	char cStr[100] = {0};
	int aSign = POSITIVE_SIGN, bSign = POSITIVE_SIGN, cSign = POSITIVE_SIGN;
	int a = 0, b = 0, c = 0;
	int shift = 0;
	
	// program currently only works for a, b or c values of at least one digit. 
	
	printf("Enter quadratic equation in the format: ax^2+bx+c=0:\n");
	myFgets(quadratic, STRING_LEN);
	
	if(quadratic[A_SIGN_INDEX] == MINUS_CHAR)
	{
		shift++;
		aSign = NEGATIVE_SIGN;
	}
	
	shift += getVariable(quadratic, A_INDEX + shift, aStr, DELIMITER_X);
	shift--; // we add the number of digits in a, but we assumed one digit.
	
	bSign = (quadratic[B_SIGN_INDEX + shift] == MINUS_CHAR ? NEGATIVE_SIGN : POSITIVE_SIGN);
	
	shift += getVariable(quadratic, B_INDEX + shift, bStr, DELIMITER_X);
	shift--;
	
	cSign = (quadratic[C_SIGN_INDEX + shift] == MINUS_CHAR ? NEGATIVE_SIGN : POSITIVE_SIGN);
	
	shift += getVariable(quadratic, C_INDEX + shift, cStr, DELIMITER_EQUAL);
	shift--; // even though shift doesn't really matter at this point...
	
	// convert strings to ints
	a = atoi(aStr) * aSign;
	b = atoi(bStr) * bSign;
	c = atoi(cStr) * cSign;
		
	solveEquation(a,b,c);

	return 0;
}


/*
Function reads a certain variable (a, b, or c) into a string
input: the quadratic equation to read from, the index to start reading from, 
and the char to write into. also a delimiter to know when to stop reading
output: how many digits the variable has
*/
int getVariable(char equation[], int eqIndex, char var[], char delim)
{
	int varIndex = 0;
	while(equation[eqIndex] != delim)
	{
		var[varIndex] = equation[eqIndex];
		eqIndex++;
		varIndex++;
	}
	var[varIndex] = 0; // finish the string of the var
	
	return strlen(var);
}

/*
Computes the delta part of the quadratic formula
of the quadratic equation a*x^2 + b*x + c = 0

Input:
	a - the coefficient of x^2
	b - the coefficient of x
	c - the constant of the quadratic equation
Output:
	The discriminant of the quadratic equation
*/
float getDelta(float a, float b, float c)
{
	return pow(b,2) - 4 * a * c;
}

/*
Computes the delta part of the quadratic formula
of the quadratic equation a*x^2 + b*x + c = 0
and prints result to screen.

Input:
	a - the coefficient of x^2
	b - the coefficient of x
	c - the constant of the quadratic equation
Output:
	None
*/
void solveEquation(float a, float b, float c)
{
	float sqrtDelta = getDelta(a,b,c);
	if (sqrtDelta > 0)
	{
		sqrtDelta = sqrt(sqrtDelta);
		printf("x1 = %.2f\n", (- b + sqrtDelta) / 2 / a);
		printf("x2 = %.2f\n", (- b - sqrtDelta) / 2 / a);
	}
	else if (sqrtDelta == 0)
	{
		printf ("x = %.2f\n", - b / 2 / a);
	}
	else
	{
		printf("No solution\n");
	}
}



/*
Function will perform the fgets command and also remove the newline 
that might be at the end of the string - a known issue with fgets.
input: the buffer to read into, the number of chars to read
*/
void myFgets(char str[], int n)
{
	fgets(str, n, stdin);
	str[strcspn(str, "\n")] = 0;
}