/*********************************
* Class: MAGSHIMIM C1			 *
* Week 11          				 *
* Homework solution  			 *
**********************************/


#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define STR_LEN 50
#define LETTERS 26
#define BOTTOM_RANGE 'a'
#define UPPER_RANGE 'z'

void encrypt(char message[]);
void myFgets(char str[], int n);

int main(void)
{
	char str[STR_LEN] = {0};
	printf("Enter a string:\n", STR_LEN - 1);
	myFgets(str, STR_LEN);
	encrypt(str);
	printf("Swapped:\n");
	printf("%s", str);
	return 0;
}

/* The function accepts a string and encrypt her by changing the most popular letter with the 2nd one
Input: a string
Output: none */
void encrypt(char str[])
{
	int letters[LETTERS] = {0},
		firstLetterCounter = 0,
		secondLetterCounter = 0;

	int index = 0;

	char firCh = '\0' , secCh = '\0';
	
	for (index = 0 ; index < strlen(str) ; index++)
	{
		// counting letters
		if (str[index] >= BOTTOM_RANGE && str[index] <= UPPER_RANGE)
		{
			// letters is a counter array:
			// letters[0] = number of times 'a' appeared
			// letters[1] = number of times 'b' appeared
			// etc.
			letters[str[index] - BOTTOM_RANGE]++;
		}
	}

	for (index = 0 ; index < LETTERS ; index++)
	{
		// finding the two most common letters
		if (letters[index] > firstLetterCounter)
		{
			secondLetterCounter = firstLetterCounter;
			secCh = firCh;
			firstLetterCounter = letters[index];
			firCh = BOTTOM_RANGE + index;
		}
		else if (letters[index] > secondLetterCounter)
		{
			secondLetterCounter = letters[index];
			secCh = BOTTOM_RANGE + index;
		}
	}
	
	printf("Most common: %c, 2nd most common: %c \n", firCh, secCh);

	for (index = 0 ; index < strlen(str) ; index++)
	{
		// replacing the biggest letters
		if (str[index] == firCh)
		{
			str[index] = secCh;
		}
		else if (str[index] == secCh)
		{
			str[index] = firCh;
		}
	}
}

/*
Function will perform the fgets command and also remove the newline 
that might be at the end of the string - a known issue with fgets.
input: the buffer to read into, the number of chars to read
*/
void myFgets(char str[], int n)
{
	fgets(str, n, stdin);
	str[strcspn(str, "\n")] = 0;
}