/*********************************
* Class: MAGSHIMIM C1			 *
* Week 11          				 *
* Homework solution  			 *
**********************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define STR_LEN 101 
void convertIntToString (int num);

int main(void)
{
	int num = 0;

	printf("Enter num: ");
	scanf("%d", &num);

	convertIntToString(num);

	return 0;
}


/* 
The function gets a number and converts it to a string
 Input: an integer
 Output: None
*/
void convertIntToString (int num)
{
	char str[STR_LEN] = "0";
	int tempNum = 0,
	    index = 1,
	    digitsNo = 0;

	if (num > 0)
	{
		str[0] = '+';
	}
	else if (num < 0)
	{
		str[0] = '-';
	}
	
	// count the digits
	tempNum = num;
	while (tempNum != 0)
	{
		tempNum /= 10;
		digitsNo++;
	}

	// need the absolute value (positive)
	if (num < 0)
	{
		num *= -1;
	}

	// convert to string
	index = digitsNo;
	while (num != 0)
	{

		str[index] = num % 10 + '0';
		num /= 10;
		index--;
	}

	// don't forget to put '\0' (null char) !
	str[digitsNo + 1] = '\0';

	printf("string: %s length: %d\n", str, strlen(str));
}


/*****************************************
******************************************
    SIMPLER SOLUTION:
	http://ideone.com/B0kZUd	
*****************************************/	