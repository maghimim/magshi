/*********************************
* Class: MAGSHIMIM C1			 *
* Week 11          				 *
* Homework solution  			 *
**********************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define STR_LEN 101
#define FALSE 0
#define TRUE !FALSE
#define LETTERS_DIFF 32

int isPalindrome(char str[]);
void myFgets(char str[], int n);
int isSameLetter(char a, char b);

int main(void)
{
	char str[STR_LEN] = { 0 };

	printf("Enter string (max length %d chars): ", STR_LEN - 1);
	myFgets(str, STR_LEN);

	if (isPalindrome(str))
	{
		printf("Yes\n");
	}
	else
	{
		printf("No\n");
	}

	return 0;
}

/* The function accepts a string and checks if it is palindrome or not.
 Input: a string
 Output: TRUE for palindrom, FALSE otherwise
 */
int isPalindrome(char str[])
{
	int right = strlen(str) - 1; 	/* starting position of right index, before the NULL*/
	int left = 0;					/* starting position of left index, string beginning*/
	int result = TRUE;				/* initially string is considered a palindrome*/

	while (left < right && result == TRUE)
	{
		// string in the left index contains a space (' '), ignore it
		if(str[left] == ' ')
		{
			++left;
		}
		// string in the right index contains a space (' '), ignore it
		else if(str[right] == ' ')
		{
			--right;
		}
		// both indices point to an ABC character (not ' ')
		else if(str[left] != str[right])
		{
				//bonus implementaion: the letters are really different
				//without the bonus, it should be just the result assignment (without the "if" statement) 
				if(!(isSameLetter(str[left], str[right])))
				{
					// Not a palindrome
					result = FALSE;
				}	
		}
		++left;
		--right;

	}
	return result;
}


/* The function accepts two chars and checks if it is the same char (case insensitive) or not.
 Input: char - the current right letter in the string.
		char - the current left letter in the string.
 Output: TRUE for identical, FALSE otherwise
 */
int isSameLetter(char a, char b)
{
	int ans = FALSE;
	if(a - b == LETTERS_DIFF || b - a == LETTERS_DIFF)
	{
		ans = TRUE;
	}
	return ans;
}



/*
Function will perform the fgets command and also remove the newline 
that might be at the end of the string - a known issue with fgets.
input: the buffer to read into, the number of chars to read
*/
void myFgets(char str[], int n)
{
	fgets(str, n, stdin);
	str[strcspn(str, "\n")] = 0;
}
