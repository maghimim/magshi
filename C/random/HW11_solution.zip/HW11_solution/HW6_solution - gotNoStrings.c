/*********************************
* Class: MAGSHIMIM C1			 *
* Week 11          				 *
**********************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
/*
There were two problems:
1. The strings were not "string"s, they were char-arrays (no zero at the end).
2. strncat gets the maximum number of characters *to be appended* - and Daniel sent more than 
the amount he used (he sent the TOTAL length of the new string instead of str2 length only).
*/
int main(void)
{
	char str1[6] = {'H', 'i', ' ', 0};
	char str2[] = {'H', 'o', 0};
	
	strncat(str1, str2, strlen(str2));
	
	printf("%s", str1);
	return 0;
}
