/*********************************
* Class: MAGSHIMIM C1			 *
* Week 11          				 *
* Homework solution  			 *
**********************************/
/*
For additional reading about password security and complexity see: 
http://safepasswordmanagement.com/password-length-vs-password-complexity/
https://xkcd.com/936/
or google "password security" or "password safety"
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define PASSWORD_LEN 10
#define MIN_PASSWORD_LEN 6
#define MAX_PASSWORD_LEN 8
#define VALID 1
#define NOT_VALID 0

#define ASCII_SMALL_A 'a'
#define ASCII_SMALL_Z 'z'
#define ASCII_BIG_A 'A'
#define ASCII_BIG_Z 'Z'
#define ASCII_DIGIT_0 '0'
#define ASCII_DIGIT_9 '9'


int validPassword(char password[]);

void myFgets(char str[], int n);

int main(void)
{
	char password[PASSWORD_LEN] = {0};
	
	printf("Enter a password: ");
	myFgets(password, PASSWORD_LEN);
	
	validPassword(password) ? printf("Yes\n") : printf("No\n"); 
	// don't know the ? operator yet? read here: http://tinyurl.com/z2ro9z5

	return 0;
}

/* The function accepts a string and checks can it be a valid password. It can be a password, if it has 6-8 chars
	capital letter, small letter a digit, and it can't have 2 same chars one after a nother.
	Input:
		Array of chars
	Output:
		Integer. 1 for valid password, 0 for none valid
*/
int validPassword(char password[])
{
	int result = NOT_VALID , smallLetter = NOT_VALID , bigLetter = NOT_VALID , digit = NOT_VALID, prev = VALID;
	int i = 0;

	if (strlen(password) >= MIN_PASSWORD_LEN && strlen(password) <= MAX_PASSWORD_LEN)
	{
		for (i = 0 ; i < strlen(password) ; i++)
		{
			// Using ASCII values for the comparison
			if (password[i] >= ASCII_SMALL_A && password[i] <= ASCII_SMALL_Z)
			{
				smallLetter = VALID;
			}
			else if (password[i] >= ASCII_BIG_A && password[i] <= ASCII_BIG_Z)
			{
				bigLetter = VALID;
			}
			else if (password[i] >= ASCII_DIGIT_0 && password[i] <= ASCII_DIGIT_9)
			{
				digit = VALID;
			}
			if (i > 0 && password[i] == password[i-1])
			{
				prev = NOT_VALID;
			}
		}

		result = smallLetter && bigLetter && digit && prev;

	}

	return result;
}


/*
Function will perform the fgets command and also remove the newline 
that might be at the end of the string - a known issue with fgets.
input: the buffer to read into, the number of chars to read
*/
void myFgets(char str[], int n)
{
	fgets(str, n, stdin);
	str[strcspn(str, "\n")] = 0;
}
